//************************************************************************
// KS108.C
// NeX
// 03.12.2006
//************************************************************************

//************************************************************************
// INCLUDES
//************************************************************************
#include <p18cxxx.h>
#include "delay.h"
#include "io_cfg.h"
//#include "font.h"

extern const rom char Font7x5[0x80*5]; 
extern const rom char Font8x8[];
//************************************************************************
// void InitDisplay(void)
//************************************************************************
void InitDisplay(void)
{
unsigned char i, j, k;
	DATA_DIR_OUT();
	WR_DATA(0x3F);
	for(i = 0; i < 3; i ++)
	{
		ChipSelect(i);
		E = 1;
		Delay100us(1);
		E = 0;
	}
	ClearDisplay();
	ChipSelect(0);
	PageSelect(0);
	RowSelect(0);
	StartLine(0);
}

//************************************************************************
// void WriteByte(unsigned char byt)
//************************************************************************
void WriteByte(unsigned char byt)
{
	WR_DATA(byt);
	E = 1;
	Delay100us(1);
	E = 0;
}


//************************************************************************
// void WriteByte(unsigned char byt)
//************************************************************************
unsigned char ReadByte(void)
{
unsigned char byt;
	RW = 1;
	DI = 0;
	DATA_DIR_IN();
	E = 1;
	byt = RD_DATA();
	Delay100us(1);
	E = 0;
	DATA_DIR_OUT();
}
//************************************************************************
// unsigned char BusyCheck(void)
//************************************************************************
unsigned char BusyCheck(void)
{
unsigned char by;
	DATA_DIR_IN();
	RW = 1;
	DI = 1;
	Delay100us(1);
	by = RD_DATA();
	DI = 0;
	by &= 0x80;
	RW = 0;
	DATA_DIR_OUT();
	return by;
}

//************************************************************************
// void ChipSelect(unsigned char page)
//************************************************************************
void ChipSelect(unsigned char chip)
{
	switch(chip)
	{
		case 0:
		{
			CSA = 0;
			CSB = 0;
		} break;
		case 1:
		{
			CSA = 0;
			CSB = 1;
		} break;
		case 2:
		{
			CSA = 1;
			CSB = 0;
		} break;
	}
}

//************************************************************************
// void PageSelect(unsigned char page)
//************************************************************************
void PageSelect(unsigned char page)
{
	RW = 0;
	DI = 0;
	WR_DATA(0xB8 | page);
	E = 1;
	Delay100us(2);
	E = 0;
//	ReadByte();
}

//************************************************************************
// void RowSelect(unsigned char page)
//************************************************************************
void RowSelect(unsigned char row)
{
	RW = 0;
	DI = 0;
	WR_DATA(0x40 | row);
	E = 1;
	Delay100us(2);
	E = 0;
//	ReadByte();
}

//************************************************************************
// void StartLine(unsigned char page)
//************************************************************************
void StartLine(unsigned char line)
{
	RW = 0;
	DI = 0;
	WR_DATA(0xC0 | line);
	E = 1;
	Delay100us(2);
	E = 0;
//	ReadByte();
}

//************************************************************************
// void WriteChar(unsigned char ch)
//************************************************************************
void ClearDisplay(void)
{
unsigned char i, j, k;
	for(i = 0; i < 3; i ++)
	{
		ChipSelect(i);
		for(j = 0; j <8; j++)
		{
			PageSelect(j);
			RowSelect(0);
			WR_DATA(0);
			DI = 1;
			for(k = 0; k < 0x40; k++)
			{
				E = 1;
				Delay100us(1);
				E = 0;
			}
		}
	}
}

//************************************************************************
// void WriteChar(unsigned char ch)
//************************************************************************
void WriteChar(unsigned char ch, unsigned char rev)
{
unsigned char i, j;
rom char *chr;
	DI = 1;
	RW = 0;
//	if(ch > 0x5E)
//		ch--;
	chr = Font8x8 + ch*8;
	for(i = 0; i < 8; i++)
	{
//	j = *chr;
	if(rev)
		WriteByte(~(*chr++));
	else
		WriteByte(*chr++);
	}
//	WriteByte(0);
	
}

//************************************************************************
// void WriteCharAt(unsigned char xpos, unsigned char ypos, unsigned char ch, unsigned char rev)
//************************************************************************
void WriteCharAt(unsigned char xpos, unsigned char ypos, unsigned char ch, unsigned char rev)
{
unsigned char i, j;
rom char *chr;
	if(xpos > 23 | ypos > 7)
		return;
	StartLine(0);
	ChipSelect(xpos/8);
	PageSelect(ypos);
	RowSelect(xpos * 8);
	DI = 1;
	RW = 0;
//	if(ch > 0x5E)
//		ch--;
	chr = Font8x8 + ch*8;
	for(i = 0; i < 8; i++)
	{
//	j = *chr;
	if(rev)
		WriteByte(~(*chr++));
	else
		WriteByte(*chr++);
	}
}
//************************************************************************
// void WriteROMString(unsigned char str[])
//************************************************************************
void WriteROMString(const rom unsigned char *str, unsigned char xpos, unsigned char ypos, unsigned char rev)
{
static unsigned char x, y, z, u;
	x = xpos;
	y = ypos;
	StartLine(0);
	while(*str)
	{
		if(x > 0x17 || y > 7) return;
		z = x/8;
		ChipSelect(z);
		PageSelect(y);
		RowSelect((x - z*8)*8);
		WriteChar(*str, rev);
		x++;
		str++;
	}
}

//************************************************************************
// void WriteROMString(unsigned char str[])
//************************************************************************
void WriteRAMString(unsigned char str[])
{
//unsigned char *string;
	while(*str)
	{
		WriteChar(*str, 0);
		str++;
	}
}

//************************************************************************
// unsigned char Button(void)
//************************************************************************
void Button(void)
{
unsigned char btn;
	while(sw2);
	Delay1ms(20);
	btn = sw2;
	if(btn == 0)
		mLED_2 = 1;
	while(!sw2);
	mLED_2 = 0;
}
