//************************************************************************
// KS108.H
// NeX
// 03.12.2006
//************************************************************************

//************************************************************************
// DEFINES
//************************************************************************
#define 	LCD_WIDTH			192
#define 	LCD_HEIGHT			64

#define 	CH_WIDTH     		6      //8x6 Font
#define 	COLS	      		LCD_WIDTH/CH_WIDTH
#define 	ROWS	      		LCD_HEIGHT/8

#define 	CSA					LATAbits.LATA4
#define 	CSA_TRIS			TRISAbits.TRISA4
#define 	CSB					LATAbits.LATA3
#define 	CSB_TRIS			TRISAbits.TRISA3
#define 	RS					LATAbits.LATA2
#define 	RS_TRIS				TRISAbits.TRISA2
#define 	RW					LATAbits.LATA1
#define 	RW_TRIS				TRISAbits.TRISA1
#define 	E					LATAbits.LATA0
#define 	E_TRIS				TRISAbits.TRISA0

#define 	DATA_DIR_IN()		TRISB=0xFF
#define 	DATA_DIR_OUT()	  	TRISB=0
#define 	WR_DATA(a)			LATB=(a)		
#define 	RD_DATA()			PORTB		
	
#define 	DATA				0
#define 	COMMAND				1

#define		OUT					0
#define		IN					1
//************************************************************************
// PROTOTYPES
//************************************************************************
extern void InitDisplay(void);
extern unsigned char BusyCheck(void);
extern void PageSelect(unsigned char page);
extern unsigned char Button(void);
