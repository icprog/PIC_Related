// Datei: delay.c
// Verz�gerungsschleifen mit Timer 0
//
// Holger Klabunde 
// 18.07.2005
// Compiler MCC18

#include <p18cxxx.h>

#include "delay.h"

//F�r interne Taktfrequenz des PIC = 12MHz (USB-Clock 48MHz)
//Prescaler 1/32
//delay<=65535 !!
//Nicht sonderlich genau !!
void Delay1ms(unsigned int time)
{
 unsigned int i;

 for(i=0; i<time; i++)
  {
   Delay100us(10);
  }
}

void Delay100us(unsigned char time)
{
 unsigned char i;

 for(i=0; i<time; i++)
  {
   INTCONbits.T0IF=0;
   TMR0L=255-38;   //Timer mit Delay setzen
   while(!INTCONbits.T0IF); //Warten bis Timer �berl�uft
  }
}
