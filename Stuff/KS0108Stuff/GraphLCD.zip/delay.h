// Datei: delay.h
//
// 18.07.2005
// Compiler MCC18

#ifndef _DELAY_H
#define _DELAY_H

extern void Delay1ms(unsigned int time);
extern void Delay100us(unsigned char time);

#endif //_DELAY_H