/********************************************************************

Demo program for testing the "GetTimeDlg", a common dialog for
getting "time" input from user. The demo asks the use for "time"
then it shows an analog clock using the time entered by the user.

Written By:
	Avinash Gupta


Copyright 2008-2012
eXtreme Electronics, India
www.eXtremeElectronics.co.in


********************************************************************/

//Graphic library
#include <gfx.h>
#include <font.h>

//Keypad libraray
#include <dpad.h>

//Analog Clock Face drawing library
#include "clock.h"

#include <util/delay.h>

//Fonts
#include "fonts/Comic12.h"	//Custom Font

//Get time dialog
#include "GetTimeDlg.h"


void main()
{
	//Initialize Graphic Driver
	GFXInit();

	//Initialize Keypad Driver
	KeypadInit();

	//Time variables
	uint8_t h,m,s,am_pm;

	h=10;
	m=10;
	s=20;
	am_pm=AM;

	GFXSetFont(Comic12);
	uint8_t ht=GFXGetCharHeight();
	uint8_t setup_button_width=GFXGetStringWidth("SETUP")+2;

	//Get initial time from user
	ShowGetTimeDlg(&h,&m,&s,&am_pm);

	while(1)
	{
		//Wait for a keybaord command
		uint8_t cmd=GetKeypadCmd(0);

		if(cmd==KEY_SOFTL)
		{
			//User pressed "SETUP"
			ShowGetTimeDlg(&h,&m,&s,&am_pm);
		}

		//Increase time
		s++;
		if(s==60)
		{
			s=0;
			m++;
			if(m==60)
			{
				m=0;
				h++;
			}
		}

		//Prepare screen
		GFXClear();
		
		//Draw the clock face
		DrawClock(h,m,s);	

		//Draw AM/PM
		if(am_pm==AM)
			GFXWriteStringXY(1,1,"AM",GFX_COLOR_BLACK);
		else
			GFXWriteStringXY(1,1,"PM",GFX_COLOR_BLACK);

		//Draw Left Soft Key (SETUP)
		GFXFillRect(1,GFX_SCREEN_HEIGHT-ht,setup_button_width,GFX_SCREEN_HEIGHT-1,GFX_COLOR_BLACK);
		GFXWriteStringXY(2,GFX_SCREEN_HEIGHT-ht+1,"SETUP",GFX_COLOR_WHITE);
		
		GFXUpdate();
		
		//Wait for a second
		_delay_ms(1000);
		
		
	}

}


