/****************************************************************************
Created with Image Converter (part of ProGFX)

ProGFX is a free Graphic Library for KS0108 based GLCDs.
Currently it is available for AVR MCUs. PIC and ARM Ports are planned.
Visit http://www.ProGFX.org for more details.


-By Avinash Gupta
Copyright (C) 2008-2011 eXtreme Electronics, India
*****************************************************************************/

#ifndef _select_bmp_H 
#define _select_bmp_H 

static unsigned char __attribute__ ((progmem)) select_bmp[]={
11,23,
0x20, 0x30, 0x38, 0x3c, 0x3e, 0x3f, 0x3e, 0x3c, 0x38, 0x30, 0x20, 
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
0x02, 0x06, 0x0e, 0x1e, 0x3e, 0x7e, 0x3e, 0x1e, 0x0e, 0x06, 0x02
};

#endif  //define _select_bmp_H 
