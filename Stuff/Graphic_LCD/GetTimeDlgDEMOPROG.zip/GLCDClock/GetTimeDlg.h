/********************************************************************

Common Dialog for getting time input from user.

*Requires ProGFX.org compatible GLCD.
*five way navigation keypad.
*Left + Right Soft keys.

Written By:
	Avinash Gupta


Copyright 2008-2012
eXtreme Electronics, India
www.eXtremeElectronics.co.in


********************************************************************/
#ifndef _GET_TIME_DLG_
#define _GET_TIME_DLG_

#define AM 0
#define PM 1

void ShowGetTimeDlg(uint8_t *h,uint8_t *m,uint8_t *s,uint8_t *am_pm);


#endif
