/********************************************************************
Simple HAL (Hardware Abstraction Layer) for a standard 
4 direction + 1 center DPAD (directional key pad). This DPAD is used
as main HID (Human Interface Device) for our GUI framework. 

The screen is handled using the ProGFX graphic driver.


Features:
	Automatic 80 FPS scanning using TIMER0
	3 point major polling for complete noice free operation
	Fully debounced.
	Automatic buffering of commands (no missed keypress!)
	Automatic repeat when user presses and hold a key.  

Written By:
	Avinash Gupta


Copyright 2008-2012
eXtreme Electronics, India
www.eXtremeElectronics.co.in
********************************************************************/

#ifndef DPAD_H
#define DPAD_H

//Keycodes

#define D_KEY_UP	0
#define D_KEY_DOWN	1
#define D_KEY_LEFT	2
#define D_KEY_RIGHT	3
#define D_KEY_ENTER	4
#define KEY_SOFTL 5
#define KEY_SOFTR 6
#define KEY_NONE	7

#define PRESSED 0
#define RELEASED 1


void KeypadInit();
uint8_t GetKeypadCmd(char wait);

#endif




