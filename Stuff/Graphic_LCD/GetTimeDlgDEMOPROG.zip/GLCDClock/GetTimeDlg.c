/********************************************************************

Common Dialog for getting time input from user.

*Requires ProGFX.org compatible GLCD.
*five way navigation keypad.
*Left + Right Soft keys.

Written By:
	Avinash Gupta


Copyright 2008-2012
eXtreme Electronics, India
www.eXtremeElectronics.co.in


********************************************************************/

//Graphic library
#include <gfx.h>
#include <font.h>

//Keypad libraray
#include <dpad.h>

//Fonts
#include <fonts/Arial12.h>	//Standard Font

//Images
#include "images/select_bmp.h"

#include "GetTimeDlg.h"

void ShowGetTimeDlg(uint8_t *h,uint8_t *m,uint8_t *s,uint8_t *am_pm)
{
	//Save Old font
	const prog_uint8_t *old_font=font;

	//Change font to Arial12
	GFXSetFont(Arial12);

	//Get Char height
	uint8_t ht=GFXGetCharHeight();

	//Draw The heading
	GFXFillRect(0,0,127,ht,GFX_COLOR_BLACK);
	GFXWriteStringXY(1,1,"Set Time",GFX_COLOR_WHITE);

	//Draw Soft Keys
	GFXFillRect(1,GFX_SCREEN_HEIGHT-ht,GFX_SCREEN_WIDTH/2-2,GFX_SCREEN_HEIGHT-1,GFX_COLOR_BLACK);
	GFXFillRect(GFX_SCREEN_WIDTH/2+2,GFX_SCREEN_HEIGHT-ht,GFX_SCREEN_WIDTH-2,GFX_SCREEN_HEIGHT-1,GFX_COLOR_BLACK);

	uint8_t x;

	//OK Button
	x=31-GFXGetStringWidth("OK")/2;
	GFXWriteStringXY(x,GFX_SCREEN_HEIGHT-ht+1,"OK",GFX_COLOR_WHITE);
	
	//Cancel Button
	x=95-GFXGetStringWidth("Cancel")/2;
	GFXWriteStringXY(x,GFX_SCREEN_HEIGHT-ht+1,"Cancel",GFX_COLOR_WHITE);



	uint8_t _h,_m,_s,_am_pm;

	_h=*h;
	_m=*m;
	_s=*s;
	_am_pm=*am_pm;

	uint8_t y=((GFX_SCREEN_HEIGHT-2*ht)/2)-(ht/2);
	y+=ht;

	uint8_t sel=0;
	

	while(1)
	{
		x=28;

		//Get Command from keypad
		uint8_t cmd=GetKeypadCmd(0);

		switch(cmd)
		{
			case D_KEY_LEFT:
				
				if(sel!=0)
				{
					sel--;
				}

				break;
			
			case D_KEY_RIGHT:
				
				if(sel!=3)
				{
					sel++;
				}

				break;

			case D_KEY_UP:
				if(sel==0)
				{
					if(_h<12)
						_h++;
				}

				if(sel==1)
				{
					if(_m<59)
						_m++;
				}

				if(sel==2)
				{
					if(_s<59)
						_s++;
				}
				if(sel==3)
				{
					if(_am_pm==AM)
						_am_pm=PM;
					else
						_am_pm=AM;
				}

				break;
			
			case D_KEY_DOWN:
				if(sel==0)
				{
					if(_h>0)
						_h--;
				}

				if(sel==1)
				{
					if(_m>0)
						_m--;
				}

				if(sel==2)
				{
					if(_s>0)
						_s--;
				}
				if(sel==3)
				{
					if(_am_pm==AM)
						_am_pm=PM;
					else
						_am_pm=AM;
				}

				break;

			case KEY_SOFTL:
				//OK
				*h=_h;
				*m=_m;
				*s=_s;
				*am_pm=_am_pm;

				goto _end;

				break;
		
			case KEY_SOFTR:
				//Cancel
				goto _end;
				
			
		}

		//Clear the main client area
		GFXFillRect(0,ht,127,GFX_SCREEN_HEIGHT-ht-1,GFX_COLOR_WHITE);


		//Draw Selection
		switch(sel)
		{
			case 0:
				GFXDrawImage(x+4,y-7,select_bmp);
				break;

			case 1:
				GFXDrawImage(x+22,y-7,select_bmp);
				break;

			case 2:
				GFXDrawImage(x+40,y-7,select_bmp);
				break;
			
			case 3:
				GFXDrawImage(x+58,y-7,select_bmp);
				break;

		}
		
	
		//Hour	
		GFXWriteIntXY(x,y,_h,2,GFX_COLOR_BLACK);
		
		x+=GFXGetStringWidth("000");
		GFXWriteStringXY(x,y,":",GFX_COLOR_BLACK);
		

		//Minute
		GFXWriteIntXY(x,y,_m,2,GFX_COLOR_BLACK);
		x+=GFXGetStringWidth("000");
		GFXWriteStringXY(x,y,":",GFX_COLOR_BLACK);
		
		//Second
		GFXWriteIntXY(x,y,_s,2,GFX_COLOR_BLACK);
		x+=GFXGetStringWidth("00:");
		x+=5;

		//AM/PM
		if(_am_pm==AM)
			GFXWriteStringXY(x,y,"AM",GFX_COLOR_BLACK);
		else
			GFXWriteStringXY(x,y,"PM",GFX_COLOR_BLACK);

		GFXUpdate();


	}	//While

	//End
	_end:

	//Restore old font
	GFXSetFont(old_font);
	
	
}
