//************************************************************************
// T6963.C
// LowLevel Routinen f�r LCD-Displays mit T6963
//
// Hier f�r Winstar WG24064A
//
// Ausgelegt bisher nur auf diesen Displaytyp
// Alle Variablen zur Koordinaten�bergabe sind 8Bit lang.
// Das reicht f�r Displays mit 128x128, 240x64 und 240x128.
//
// Der Nullpunkt des Displays liegt oben,links. F�r unten rechts
// m�ssen dann zus�tzliche Umrechnungen stattfinden.
//
// Mit SetPixel hat man den Grundstein f�r alle
// erdenklichen Zeichenroutinen:
// Linien, Rechtecke, Kreise, F�llen, Muster
//
// Was witziges nebenbei: Wenn das Display von einer Leuchtstofflampe
// Energiesparlampe beleuchtet wird, flimmert es unangenehm !
// Interferenzerscheinung.
// Da hat Winstar eine schlechte Quarzfrequenz gew�hlt.
// H�lt man eine Taschenlampe drauf ist es v�llig ruhig.
//
// 01.04.2002 CheckBusy() als Routine entfernt.
//            Mehr Code aber schneller. Makro draus gemacht
//            Eigentlich ein CheckBusy2() bei einigen Befehlen n�tig, geht aber.
//            WriteDisplay() entfernt und zwei Routinen WriteData(),WriteCommand()
//            draus gemacht.
//
// holger.klabunde@t-online.de
// Compiler SDCC
//************************************************************************

#include "protos.h"
#include "T6963.h"

xdata at 0x7FFE unsigned char t6963data;
xdata at 0x7FFF unsigned char t6963ctrl;

//##########################################################
//LowLevel ReadDisplay
unsigned char ReadDisplay()
{
 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=0xC1; //Auto Read

 CheckBusy(); //StatusBits STA0,1 checken
 return t6963data;
}

//##########################################################
//Schreibt ein Datenbyte und ein Kommandobyte
void WriteData1(unsigned char dat, unsigned char command)
{
 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=dat; //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=command; //Kommando schreiben
}

//##########################################################
//Schreibt zwei Datenbytes und ein Kommandobyte
void WriteData2(unsigned int dat, unsigned char command)
{
 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(dat&0xFF); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(dat>>8); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=command; //Kommando schreiben
}

//##########################################################
//Datenbyte schreiben
void WriteData(unsigned char dat)
{
 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=dat; //Daten schreiben
}

//##########################################################
//Kommandobyte schreiben
void WriteCommand(unsigned char command)
{
 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=command; //Kommando schreiben
}

//##########################################################
//Pixel auf dem Display setzen
//mode=0; Pixel l�schen
//mode=1; Pixel setzen
void SetPixel(unsigned char xpos, unsigned char ypos, unsigned char mode)
{
 unsigned int adress;
 unsigned char tmp,pixel;

 if(xpos>=LCD_WIDTH) return; //Punkt au�erhalb der Anzeige
 if(ypos>=LCD_HEIGHT) return;

 tmp=(unsigned char) xpos % PIXPERBYTE; //Position des Pixels im Byte

/*
 if(drawmode==P_INVERT) //Pixel negativ zeichnen
  {
   if(pixset==0) pixset=1; //invertieren
   else pixset=0;
  }
*/

 if(mode==0) pixel=0xF0; //Kommando Pixel l�schen
 else pixel=0xF8;        //Kommando Pixel setzen

 switch(tmp) //Die Reihenfolge der Pixel ist im Byte genau umgekehrt !
  {
   case 0: tmp=7; break;
   case 1: tmp=6; break;
   case 2: tmp=5; break;
   case 3: tmp=4; break;
   case 4: tmp=3; break;
   case 5: tmp=2; break;
   case 6: tmp=1; break;
   case 7: tmp=0; break;
   default: break;
  }

 pixel|=tmp; //Position des Pixels im Byte setzen

//Position im Display-RAM setzen
//war vorher SetPosition(xpos,ypos);
 adress=GRAPH_AREA; //Start of Grafikarea

//anhand von xpos und ypos ermitteln welches Byte
//gelesen/geschrieben werden soll
 adress+=((LCD_WIDTH/PIXPERBYTE)*ypos);
 adress+=xpos/PIXPERBYTE;

//Set address pointer
 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(adress&0xFF); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(adress>>8); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=0x24; //Kommando schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=pixel; //Befehl mit gew�nschtem Pixel schreiben
}

//##########################################################
//Zustand des Pixels an Stelle x,y lesen
unsigned char GetPixel(unsigned char xpos, unsigned char ypos)
{
 unsigned char by,tmp,pix;

 if(xpos>=LCD_WIDTH) return 0xFF; //Punkt au�erhalb der Anzeige
 if(ypos>=LCD_HEIGHT) return 0xFF;

 SetPosition(xpos,ypos); //Position auf 8 Pixel genau setzen
 by=ReadDisplay();       //8 Pixel lesen

 tmp=xpos % PIXPERBYTE; //Position des Pixels im Byte
//Grrrr. Pixel 0 sitzt im Byte an der !! h�chsten !! Stelle
 pix= 0x80 >> tmp;             //An die richtige Position schieben

 if(by&pix) return 1; //war gesetzt
 else return 0;       //war nicht gesetzt
}

//##########################################################
//Gew�nschte Koordinate auf dem Display einstellen
void SetPosition(unsigned char xpos, unsigned char ypos)
{
 unsigned int adress;

 if(xpos>=LCD_WIDTH) return; //Punkt au�erhalb der Anzeige
 if(ypos>=LCD_HEIGHT) return;

 adress=GRAPH_AREA; //Start of Grafikarea

//anhand von xpos und ypos ermitteln welches Byte
//gelesen/geschrieben werden soll
 adress+=((LCD_WIDTH/PIXPERBYTE)*ypos);
 adress+=xpos/PIXPERBYTE;

//Set address pointer
 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(adress&0xFF); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963data=(unsigned char)(adress>>8); //Daten schreiben

 CheckBusy(); //StatusBits STA0,1 checken
 t6963ctrl=0x24; //Kommando schreiben
}

//##########################################################
void DisplayOn()
{
//Write text home address=0x0000
 WriteData2(TEXT_AREA,0x40);

//Write graphic home address
 WriteData2(GRAPH_AREA,0x42);

//Text area column set= Setze Textspalten 
//Write text area address=001FH = 30 Spalten
//Set Low bit= MaxColumn/8
 WriteData2(LCD_WIDTH/CHARWIDTH,0x41);
//Der 6x8 Font l��t sich leider nur im reinen Textmodus
//nutzen. Das ergibt 8 Zeilen mit 40 Zeichen !
//Die Grafikanzeige wird versaut wenn er aktiviert
//wird. Sie wird dann scheinbar auch nur mit 6 Pixeln pro
//Byte benutzt. Das w�rde aber das ganze Programm
//zum laden von Bitmaps/Fonts zunichte machen. Deshalb la� ich den
//Font auf 8x8. Sieht zwar Schei�e aus, aber zur Not kann man
//ja Schrift mit Grafik erzeugen. 


//Graphics area column set in Bytes !!!
//Write graphic area address=001FH = 30 Bytes
//Set Low bit= MaxColumn/8
 WriteData2(LCD_WIDTH/PIXPERBYTE,0x43);

//set display mode = OR
 WriteCommand(0x80);

//Text and graphic display !!
 WriteCommand(0x9C);

 ClearScreen(); //L�scht das Text UND Graphic RAM !
}

//##########################################################
// Zeichen von Windows nach T6963 konvertieren
unsigned char ConvertText(unsigned char ch)
{
 unsigned char tmp;

 tmp=ch;

//Die case-Werte sind bezogen auf den SystemFont !!!
 switch(ch)
  {
   case 196: tmp=0x6E; break; // �
   case 228: tmp=0x64; break; // �
   case 214: tmp=0x79; break; // �
   case 246: tmp=0x74; break; // �
   case 220: tmp=0x7A; break; // �
   case 252: tmp=0x61; break; // �
   case 223: tmp=223; break; // �
   default: tmp-=0x20; break;
  }

 return tmp;
}

//##########################################################
// Text horizontal schreiben
void LCDText(char *txt, unsigned char xpos, unsigned char ypos)
{
 char ps;

 WriteData2(xpos+(LCD_WIDTH/CHARWIDTH)*ypos,0x24);

 while((ps = *txt)) //Solange Zeichen gr��er 0x00
  {
   txt++; //N�chstes Zeichen
   if (ps== 0) break; //Raus wenn Zeichen gleich 0
   ps=ConvertText(ps); //�bersetzungstabelle aufrufen
   WriteData1(ps,0xC0); //Write ps, Auto Inkrement
  }
}

//##########################################################
// Kompletten Bildschirm l�schen
void ClearScreen()
{
 unsigned char j;
 int i;

//Write text home address
//Set address pointer = Text home
 WriteData2(TEXT_AREA,0x24);
 WriteCommand(0xB0);
//ClearText RAM
//Witzigerweise bleibt der Inhalt des Text RAM
//ohne Stromversorgung noch recht lange erhalten ;) 
 for(i=0; i<(LCD_WIDTH/CHARWIDTH * LCD_HEIGHT/8); i++) WriteData(0x00);
 WriteCommand(0xB2);

 WriteData2(GRAPH_AREA,0x24); //An Position 0:0

 WriteCommand(0xB0); //Auto Write

 for(j=0; j<LCD_HEIGHT; j++)
  {
   for(i=0; i<(LCD_WIDTH/PIXPERBYTE); i++) WriteData(0x00);
  }

 WriteCommand(0xB2); //Auto Reset
}

//##########################################################
// Kompletten Bildschirm f�llen
void FillScreen()
{
 unsigned char i,j;

 WriteData2(GRAPH_AREA,0x24); //An Position 0:0

 WriteCommand(0xB0); //Auto Write

 for(j=0; j<LCD_HEIGHT; j++)
  {
   for(i=0; i<(LCD_WIDTH/PIXPERBYTE); i++) WriteData(0xFF);
  }

 WriteCommand(0xB2); //Auto Reset
}

