//Datei: LCD.C
//
//Ansteuerung von ein- bzw. zweizeiligen
//Standard LCD-Displays mit 14poligem Anschlu�
//
//Standardmodus mit 8Bit Daten�bertragung
//
//Holger Klabunde
//09.08.1999
//
//Compiler SDCC

#include "protos.h"

xdata at 0x7FEE unsigned char lcdctrl ;
xdata at 0x7FEF unsigned char lcddata ;

//Schreibt ein einzelnes Byte in die LCD-Anzeige
void LCDWriteByte(unsigned char by)
{
 lcddata=by;
 Delay100us();
}

//Schreibt einen String in die LCD-Anzeige
void LCDWrite(char *__putstr)
{
 char __ps;

 while((__ps = *__putstr))
  {
   __putstr++;
   if (__ps== 0) break;
   lcddata=__ps;
   Delay100us();
  }
}

//Arbeitsmode der LCD_Anzeige einstellen
void LCDInit()
{
 //Software-Reset der LCD-Anzeige auch ohne Powerup
 //z.B. Reset �ber TL7705 wegen kurzem Vcc-Einbruch
 Delay1ms(50); //Evtl. Powerup abwarten
 lcdctrl=0x38; //8Bit Operation (D0-D3 egal)
 Delay1ms(5); //Laut Datenblatt >4.1ms
 lcdctrl=0x38; //8Bit Operation
 Delay1ms(1); //Laut Datenblatt >100us
 lcdctrl=0x38; //8Bit Operation
 Delay1ms(1);
//Laut Datenblatt hier Sofware-Reset beendet
 
 //Ab hier Initialisierung der LCD-Anzeige
 lcdctrl=0x38; //8Bit Operation
 Delay1ms(2);
 lcdctrl=0x08; //Display off
 Delay1ms(2);
 lcdctrl=0x01; //Display Clear
 Delay1ms(5);
 lcdctrl=0x06; //CursorPos Increment,Display steht
 Delay1ms(2);

 lcdctrl=0x0C; //Display on, Cursor off
 Delay1ms(2);
 lcdctrl=0x14; //Cursor bewegen,Richtung rechts
 Delay1ms(2);
 lcdctrl=0x02; //Cursor Home
 Delay1ms(2);
}

//LCD-Anzeige l�schen
void LCDCls()
{
 lcdctrl=0x01;
 Delay1ms(5);
}

//Cursor positionieren
//Keine Abfrage auf ung�ltige Werte !!!
//Die Anzeige beginnt bei mir mit Zeile1, Position1
void LCDPos(unsigned char line, unsigned char position)
{
 unsigned char help; //F�r Zwischenwerte

//0x80 damit Bit 7 gesetzt, DisplayAdressSet
//0x40 bei 2 f�r Offset Zeile1 zu Zeile2
 switch(line)
  {
   case 1: help=0x80+(position-1); break;
   case 2: help=0x80+0x40+(position-1); break;
   case 3: help=0x80+20+(position-1); break;
   case 4: help=0x80+0x40+20+(position-1); break;
  }
 lcdctrl=help; //Ab ins LCD-Kontrollregister
 Delay100us();
}

//Zeigt ein Byte im Hexadezimalcode an
void ShowHex(unsigned char by)
{
 unsigned char buff;
 LCDWrite("0x");
 buff=(by>>4)&0x0F; //Hignibble zuerst
 if(buff<10) buff+=0x30; //ASCII Code erzeugen
 else buff+=0x37;        //Gro�buchstaben
 LCDWriteByte(buff);

 buff=by&0x0f; //Danach das Lownibble
 if(buff<10) buff+=0x30; //ASCII Code erzeugen
 else buff+=0x37;        //Gro�buchstaben
 LCDWriteByte(buff);
}

