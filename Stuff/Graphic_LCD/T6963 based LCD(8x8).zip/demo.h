//#####################################
//Datei wurde erzeugt von BMP2C V1.00
//holger.klabunde@t-online.de
//#####################################

#define demoWIDTH 240 //Breite in Pixeln
#define demoBYTEWIDTH 30 //Breite in Bytes
#define demoHEIGHT 64 //H�he in Pixeln

//extern const unsigned char code demobmp[];
extern const unsigned char demobmp[];
