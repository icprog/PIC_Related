//************************************************************************
// Bitmap.C
//
// Bitmaps an beliebige Position zeichnen
// Bisher nur Bitmaps aus dem EProm
// Optimiert auf schreiben von 8 Pixeln gleichzeitig
//
// Der Nullpunkt der Anzeige ist links oben
//
// Das laden der Bitmap ist wesentlich schneller wenn
// man genau auf einer durch 8 teilbaren X-Position anf�ngt.
// Dann k�nnen 8 Pixel in einem Rutsch geschrieben werden.
//
// Der schnelle Teil der Routine �berschreibt den alten Inhalt !
// D.h. besser erst die Bitmap laden und dann darin zeichnen.
//
// Verbesserungen:
// Eine ganze Zeile in einen Puffer lesen. Dann solange
// einzelne Pixel schreiben bis eine durch 8 teilbare Position
// erreicht ist. Dabei die Pixel der Zeile schieben !
//
// Die Bitmap sollte an der entsprechenden Position nicht die
// Displaygrenzen �berschreiten. Das wird nicht besonders genau
// �berwacht, weil das ganz einfach Zeit kostet.
//
// Holger Klabunde
// 08.04.2002
// Compiler SDCC
//************************************************************************
#include "protos.h"
#include "t6963.h"

//##########################################################
void LoadBitmap(unsigned char *bitmap,unsigned char xpos , unsigned char ypos, unsigned char width, unsigned char height)
{
 unsigned char bwidth,i,j,k,yp,xp;
 unsigned char by,mask;
 unsigned int xend;     //xpos + width kann gr��er als 255 werden

 xend=(unsigned int)xpos+(unsigned int)width;
 if(xend>LCD_WIDTH) xend=LCD_WIDTH; //Bitmap abschneiden wenn au�erhalb des Displays
 
 bwidth=width/8; //Anzahl Bytes horizontal
 if((width%8)!=0) bwidth++; //Bei Rest noch ein Byte mehr

 yp=ypos;
 for(i=0; i<height; i++) //�ber die gesamte H�he
  {
   xp=xpos; //Zum Beginn der Zeile

   for(j=0; j<bwidth; j++) //�ber die gesamte Breite in Bytes
    {
     by=*bitmap;

     //Bitmaps am besten immer an durch 8 teilbare x-Positionen setzen !
     //Dann kann man 8 Pixel gleichzeitig schreiben.
     if((xp % 8 ==0) && (xp < LCD_WIDTH-8) && (yp < LCD_HEIGHT)) //Die schnelle Methode
      {
         SetPosition(xp,yp);
         WriteData1(by,0xC0);
         xp+=8;
      }
     else //Die langsame Methode
      {
       mask=0x80;         //F�ngt bei MSB an

       for(k=0; k<8; k++) //�ber ein Byte
        {
          //Nur vorhandene und keine F�llpixel,-bytes zeichnen
          if(xp < (unsigned char)xend)
          {
           SetPixel(xp,yp,(by&mask));
           xp++; 
          }                               

         mask>>=1; //N�chstes Bit
        }//for k
      }//else

     bitmap++;
    } //for j

   yp++; //N�chste Zeile
  } //for i
}

