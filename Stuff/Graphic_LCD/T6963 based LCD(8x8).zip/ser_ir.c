//Datei: ser_ir.C
//
//Serielle Interrupts
//und Zeicheneingabe-ausgabe Funktionen
//Empfang im Hintergrund
//
//Holger Klabunde
//07.12.2001
//
//Compiler SDCC

/*-------------------------------------------------------------------------
  ser_ir.c - source file for serial routines 
  
  Written By - Josef Wolf <jw@raven.inka.de> (1999) 
  
	 This program is free software; you can redistribute it and/or modify it
	 under the terms of the GNU General Public License as published by the
	 Free Software Foundation; either version 2, or (at your option) any
	 later version.
	 
	 This program is distributed in the hope that it will be useful,
	 but WITHOUT ANY WARRANTY; without even the implied warranty of
	 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 GNU General Public License for more details.
	 
	 You should have received a copy of the GNU General Public License
	 along with this program; if not, write to the Free Software
	 Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
	 
	 In other words, you are welcome to use, share and improve this program.
	 You are forbidden to forbid anyone else to use, share and improve
	 what you give them.   Help stamp out software-hoarding!

-------------------------------------------------------------------------*/
//Aus dem SDCC C-Compiler Paket f�r 8051

#include "prozess.h"
#include "protos.h"

/* This file implements a serial interrupt handler and its supporting
* routines. Compared with the existing serial.c and _ser.c it has
* following advantages:
* - You can specify arbitrary buffer sizes (umm, up to 255 bytes),
*   so it can run on devices with _little_ memory like at89cx051.
* - It won't overwrite characters which already are stored in the
*   receive-/transmit-buffer.
* - It checks receiver first to minimize probability for overruns
*   in the serial receiver.
*/

#define RBUFLEN 4

unsigned char rbuf[RBUFLEN];
unsigned char rcnt, rpos;

bit busy;
//unsigned char busy,recbuf;

void ser_init (void)
{
   ES = 0;
   rcnt = rpos = 0;  /* init buffers */
   busy = 0;
   SCON = 0x50;
// PCON=0x80; //Doppelte Baudrate f�r 89C52

   TMOD &= 0x0f;                   /* use timer 1 */

   TMOD |= 0x20;
   TL1 = BAUD4800; TH1 = BAUD4800; TR1 = 1;

   ES = 1;
   TI=1; //Geht auch ohne. Ist aber besser
   PS=1; //High Interrupt Priority f�r seriell
}

void ser_handler (void) interrupt 4 using 1
{
   if(RI) //Empfangsint.
    {
//     recbuf=SBUF; //Schnell sichern
     RI = 0;
     /* don't overwrite chars already in buffer */
     if (rcnt < RBUFLEN)  rbuf [(rpos+rcnt++) % RBUFLEN] = SBUF;
//     if (rcnt < RBUFLEN)  rbuf [(rpos+rcnt++) % RBUFLEN] = recbuf;
    }
    
   if(TI) //Sendeint.
    {
     TI = 0;
     busy=0; //Byte gesendet
    }
}

void ser_putc (unsigned char c)
{
//Nicht zu warten ist schlecht !
//Die Zeichenausgabe leidet dann !
//   while (xcnt >= XBUFLEN); /* wait for room in buffer */
   while (busy==1); //warten bis letztes Byte gesendet wurde
   
   ES = 0;
   SBUF = c;
   busy = 1;
   
   ES = 1;
}

#pragma SAVE
#pragma NOGCSE
unsigned char ser_getc (void)
{
 unsigned char c;

 while (!rcnt)
 {
 };   /* wait for character */
//   if(!rcnt) return 0; //Nix im Puffer, dann raus

   ES = 0;
   rcnt--;
   c = rbuf [rpos++];
   if (rpos >= RBUFLEN)  rpos = 0;
   ES = 1;
   return (c);
}
#pragma RESTORE

void ser_puts (unsigned char *s)
{
 unsigned char c;
   while (c=*s++)
    {
     if (c == '\n')
      {
       ser_putc(0x0D); //CR
       ser_putc(0x0A); //LF
      }
     else ser_putc (c);
    }
}

/* nicht ben�tigt
int ser_gets (unsigned char *s, unsigned char len)
{
   unsigned char pos, c;

   pos = 0;
   while (pos <= len)
    {
     c = ser_getc ();
     s[pos++] = c;         
     if(c == 0x0D) break;  //CR ist das Zeichen f�r Ende des Strings
   }
   s[pos] = '\0'; //Stringende eintragen

 return pos-1; //Anzahl empfangener Zeichen ohne 0x0d,0x0a zur�ckgeben
}
*/
