//Datei: PROTOS.H
//
//Nur Prototypen
//
//Holger Klabunde
//17.03.2002
//
//Compiler SDCC

#ifndef PROTOS_H	//Mehrfaches include vermeiden
#define PROTOS_H

#include "display.h"

//fontsoft.c
extern void SetFont(unsigned char num);
extern void LCDSoftChar(unsigned char ch, unsigned char xpos, unsigned char ypos);
extern void LCDSoftText(char *__putstr, unsigned char xpos, unsigned char ypos);
extern void ShowSoftFont(unsigned char num);

//draw.c
extern void DrawLine(unsigned char x1, unsigned char y1, unsigned char x2, unsigned char y2);
extern void FillRect(unsigned char x, unsigned char y, unsigned char width, unsigned char height);
extern void DrawRect(unsigned char x, unsigned char y, unsigned char width, unsigned char height);
extern void DrawYLineLen(unsigned char y, unsigned char len, unsigned char x);
extern void DrawXLineLen(unsigned char x, unsigned char len, unsigned char y);
extern void DrawYLine(unsigned char y1, unsigned char y2, unsigned char x);
extern void DrawXLine(unsigned char x1, unsigned char x2, unsigned char y);

//Bitmap.c
extern void LoadBitmap(unsigned char *bitmap,unsigned char xpos , unsigned char ypos, unsigned char width, unsigned char height);

//T6963.c
extern unsigned char ReadDisplay();
extern void WriteData1(unsigned char, unsigned char);
extern void WriteData2(unsigned int, unsigned char);
extern void WriteData(unsigned char dat);
extern void WriteCommand(unsigned char command);
extern void SetPixel(unsigned char xpos, unsigned char ypos, unsigned char mode);
extern unsigned char GetPixel(unsigned char xpos, unsigned char ypos);
extern void SetPosition(unsigned char xpos, unsigned char ypos);
extern void DisplayOn();
extern void ClearScreen();
extern void FillScreen();
extern unsigned char ConvertText(unsigned char ch);
extern void LCDText(char *txt, unsigned char xpos, unsigned char ypos);

//Ansteuerung der LCD-Anzeige LCD.C
extern void LCDInit();
extern void LCDPos(unsigned char,unsigned char);
extern void LCDCls();
extern void LCDWrite(char *);
extern void LCDWriteByte(unsigned char);
extern void ShowHex(unsigned char);

//ser_ir.c
extern void ser_init (void);
extern void ser_putc (unsigned char c);
extern void ser_puts (unsigned char *s);
extern int ser_gets (unsigned char *s, unsigned char len);
extern unsigned char ser_getc (void);
extern unsigned char rcnt, rpos;
extern bit busy;

//Hardwareeinstellung beim Start
extern void InitHardware();
extern void Delay1ms(unsigned int);
extern void Delay100us();

//Globale Variablen
extern unsigned char timeout;

#endif
