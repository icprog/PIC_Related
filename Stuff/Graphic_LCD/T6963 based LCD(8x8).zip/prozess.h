#include <8052.h>
sfr at 0x8F CKCON       ; // Doppelte Geschwindigkeit f�r 80C32X2 Prozessoren
                          // Liegt nicht wie bei 80C320 bei 0x8E sondern 0x8F

//irgendwann im Quellcode dann
//CKCON=0x01; //F�r doppelte Geschwindigkeit. Achtung Timer und USART
              //arbeiten dann auch mit doppelter Geschwindigkeit !                          
