//#####################################
//Datei wurde erzeugt von BMP2C V1.00
//holger.klabunde@t-online.de
//#####################################

#define paulWIDTH 67 //Breite in Pixeln
#define paulBYTEWIDTH 9 //Breite in Bytes
#define paulHEIGHT 64 //H�he in Pixeln

//extern const unsigned char code paulbmp[];
extern const unsigned char paulbmp[];
