//Datei: gpslogg.H
//Headerdatei f�r gpslogg.C
//Hardwaredefinitionen
//
//Holger Klabunde
//C innotec 2001
//09.12.2001
//
//Compiler SDCC

#ifndef GPSLOGG_H	//Mehrfaches include vermeiden
#define GPSLOGG_H

#define BAUD4800	0xFA
//#define BAUD9600	0xFD
//#define BAUD19200	0xFD

//Timer0 Interrupt. 16 Bit Z�hler
//11.059MHz / 12 = ein Maschinenzyklus
//Interrupt alle (12*65536)/11.059MHz = 71.1ms

sbit at 0x97 P17; //Bit 7 von PORT 1

//Der 8051 kann nur gegen 0 etwas Strom ziehen. Deshalb
//Ausgang f�r die LED invertiert
#define LED_ON() { P17 = 0; } //Invertierte Ausgabe
#define LED_OFF() { P17 = 1; } //Invertierte Ausgabe

#endif
