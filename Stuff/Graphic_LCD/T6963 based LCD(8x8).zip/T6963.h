//************************************************************************
// T6963.H
//
// LCD Gr��e und Grundeinstellungen angeben
// F�r 8x8 interner Font
//
// Holger Klabunde
// 08.04.2002
//************************************************************************
#ifndef t6963_h
#define t6963_h // Mehrfaches 'includen' vermeiden

#define LCD_WIDTH	240
#define LCD_HEIGHT	64

#define TEXT_AREA     0
#define GRAPH_AREA    0xC00
#define CHARWIDTH     8
#define PIXPERBYTE    8

#define CheckBusy() while((t6963ctrl & 3) != 3); 

#endif // t6963_h
