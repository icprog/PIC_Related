//************************************************************************
// Draw.C
//
// Linien zeichnen, Strichbreite immer 1
// Rechtecke zeichnen und gef�llte Fl�chen
// Zeichnet nur absolute Koordinaten
// Der Endpunkt wird nicht gespeichert
// Optimiert auf schreiben von 8 Pixeln gleichzeitig
//
// Der Nullpunkt der Anzeige ist links oben
//
// Holger Klabunde
// 01.04.2002
// Compiler SDCC
//************************************************************************
#include <stdlib.h>
#include "protos.h"
#include "t6963.h"

//##########################################################
// Zeichnet eine Linie von X1,Y1 bis X2,Y2
// gefunden im Internet. http://www.prog.cz/swag/swag/graphics/
void DrawLine(unsigned char x1, unsigned char y1, unsigned char x2, unsigned char y2)
{
 int x,y,count,xs,ys,xm,ym;

 x=(int)x1; y=(int)y1;
 xs=(int)x2-(int)x1; ys=(int)y2-(int)y1;
 if(xs<0) xm=-1; else if(xs>0) xm=1; else xm=0;
 if(ys<0) ym=-1; else if(ys>0) ym=1; else ym=0;
// xs=abs(xs);  ys=abs(ys);
 if(xs<0) xs=-xs;
 if(ys<0) ys=-ys;

 SetPixel((unsigned char)x,(unsigned char)y,1);

 if(xs>ys) // Flache Linie <45 Grad
  {
   count=-(xs/2);

   while(x!=x2 )
    {
     count=count+ys;
     x=x+xm;

     if(count>0)
      {
       y=y+ym;
       count=count-xs;
      }

     SetPixel((unsigned char)x,(unsigned char)y,1);
    }
   }
  else // Steile Linie >=45 Grad
   {
    count=-(ys/2);

    while(y!=y2)
	 {
      count=count+xs;
      y=y+ym;

      if(count>0)
       {
        x=x+xm;
        count=count-ys;
       }

      SetPixel((unsigned char)x,(unsigned char)y,1);
     }
   }
}

//##########################################################
// Zeichnet eine horizontale Linie von X1 bis X2 auf Zeile Y
void DrawXLine(unsigned char x1, unsigned char x2, unsigned char y)
{
 unsigned char i,xstart,xend;

 if(x2>x1) //Immer von links nach rechts zeichnen
  { xstart=x1; xend=x2; }
 else
  { xstart=x2; xend=x1; }
 
//Optimierung f�r horizontale Linien >= 8 Pixel
//Dann 8 Pixel gleichzeitig schreiben
 if( (xend-xstart+1) >= PIXPERBYTE )
  {
 //Solange einzelne Pixel schreiben bis xstart%PIXPERBYTE Null ergibt
 //danach kann man PIXPERBYTE Pixel gleichzeitig schreiben !
 //Wenn noch soviele zu schreiben sind !!! Aufpassen. 
   while((xstart % PIXPERBYTE) != 0)
    {
     SetPixel(xstart,y,1);
     xstart++;
    }

//Ab hier PIXPERBYTE Pixel gleichzeitig schreiben !
//Achtung Displaygrenzen checken !
   while( (xstart+PIXPERBYTE <xend) && (xstart+PIXPERBYTE < LCD_WIDTH))
    {
	 SetPosition(xstart,y);
         WriteData1(0xFF,0xC0);
	 xstart+=PIXPERBYTE;
	}
//Ende PIXPERBYTE Pixel gleichzeitig schreiben

//Eventuelle Restpixel schreiben
   while(xstart <= xend)
    {
     SetPixel(xstart,y,1);
     xstart++;
    }

  }
 else //Die langsame Methode
  {
   for(i=xstart; i<=xend; i++)
    {
     SetPixel(i,y,1);
    }
  }
}

//##########################################################
// Zeichnet eine vertikale Linie von Y1 bis Y2 auf Spalte X
void DrawYLine(unsigned char y1, unsigned char y2, unsigned char x)
{
 unsigned char i,ystart,yend;

 if(y2>y1)
  { ystart=y1; yend=y2; }
 else
  { ystart=y2; yend=y1; }

 for(i=ystart; i<=yend; i++)
  {
   SetPixel(x,i,1);
  }
}

//#########################################################################
// Zeichnet eine horizontale Linie mit L�nge len ab Position X auf Zeile Y
// Von links nach rechts
void DrawXLineLen(unsigned char x, unsigned char len, unsigned char y)
{ DrawXLine(x,x+len-1,y); }

//#########################################################################
// Zeichnet eine vertikale Linie mit L�nge len ab Position Y auf Spalte X 
// Von oben nach unten
void DrawYLineLen(unsigned char y, unsigned char len, unsigned char x)
{ DrawYLine(y,y+len-1,x); }

//#########################################################################
// Zeichnet ein Rechteck Breite width H�he height ab Position X,Y 
void DrawRect(unsigned char x, unsigned char y, unsigned char width, unsigned char height)
{
 DrawXLineLen(x,width,y);
 DrawXLineLen(x,width,y+height-1);
 DrawYLineLen(y,height,x);
 DrawYLineLen(y,height,x+width-1);
}

//#########################################################################
// F�llt ein Rechteck Breite width H�he height ab Position X,Y 
void FillRect(unsigned char x, unsigned char y, unsigned char width, unsigned char height)
{
 unsigned char i;

 for(i=y; i<(y+height); i++) DrawXLineLen(x,width,i);
}
