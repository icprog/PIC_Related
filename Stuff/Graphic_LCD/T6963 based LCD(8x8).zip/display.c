// Datei: display.c
// Hauptprogramm
//
// Text und Grafik auf
// T6963 Grafik-LCD-Display anzeigen
// Display: Winstar WG24064A 240x64 Pixel
//
// Holger Klabunde
// 31.03.2002
//
// Compiler SDCC

#include "prozess.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "protos.h"
#include "T6963.h"
#include "paul.h"
#include "demo.h"

//Interrupthandler auf jeden Fall f�r main() bekanntmachen !
void ser_handler (void) interrupt 4 using 1;
void Timer0Int(void) interrupt 1 using 2;

unsigned char timeout;

main()
{
 int i;
 
 InitHardware();
 LCDInit();
 LCDCls();
 LCDWrite("Holgi's Grafikdemo"); //Text auf dem Textdisplay
 LCDPos(2,1);
 LCDWrite("Winstar Display mit T6963 Controller");
 Delay1ms(1000);
 
 ser_init(); //Serielle Schnittstelle einstellen

 DisplayOn();

//Beginn Endlosschleife
 while(1)
  {

 ClearScreen();
 LCDCls();
 LCDWrite("Interner Font"); //Text auf dem Textdisplay
//Hardware Font. Schreiben ist schnell, aber nur grob plazierbar wie auf einem
//LCD-Textdisplay
 LCDText("Interner 8x8 Font",0,0); //Text auf dem Grafikdisplay
 for(i=1; i<8; i++) LCDText("Hello World",0,i);
 Delay1ms(3000);

 ClearScreen();
 LCDCls();
 LCDWrite("Bitmaps zeichnen"); //Text auf dem Textdisplay
 LoadBitmap(paulbmp, 0 , 0, paulWIDTH, paulHEIGHT);   //Bitmap schnell laden
 LoadBitmap(paulbmp, 121 , 0, paulWIDTH, paulHEIGHT); //Bitmap langsam laden
 LoadBitmap(paulbmp, 199 , 32, paulWIDTH, paulHEIGHT); //Bitmap abschneiden
 Delay1ms(3000);

 ClearScreen();
 LCDCls();
 LCDWrite("Gro�e Bitmap zeichnen"); //Text auf dem Textdisplay
 LoadBitmap(demobmp, 0 , 0, demoWIDTH, demoHEIGHT);   //Bitmap f�llt ganzes Display
 Delay1ms(3000);

 ClearScreen();
 LCDCls();
 LCDWrite("Bildschirm f�llen"); //Text auf dem Textdisplay
 DrawRect(0,0,LCD_WIDTH,LCD_HEIGHT);     //Ganzen Bildschirm mit 3 Pixel Breite umranden
 DrawRect(1,1,LCD_WIDTH-2,LCD_HEIGHT-2);
 DrawRect(2,2,LCD_WIDTH-4,LCD_HEIGHT-4);
 
 FillRect(5,5,LCD_WIDTH-10,LCD_HEIGHT-10); //Gro�e Fl�che f�llen, flimmert es ? ;)
 Delay1ms(3000);

 ClearScreen();                     
 LCDCls();
 LCDWrite("Linien zeichnen"); //Text auf dem Textdisplay
 DrawRect(0,0,LCD_WIDTH,LCD_HEIGHT);
 DrawLine(0,0,LCD_WIDTH,LCD_HEIGHT); //Schr�ge Linien zeichnen links nach rechts
 DrawLine(LCD_WIDTH,0,0,LCD_HEIGHT); //und andersrum
 DrawLine(0,0,LCD_WIDTH/2,LCD_HEIGHT); //Schr�ge Linien zeichnen links nach rechts
 DrawLine(LCD_WIDTH/2,0,0,LCD_HEIGHT); //und andersrum
 DrawLine(LCD_WIDTH/2,0,LCD_WIDTH,LCD_HEIGHT); //Schr�ge Linien zeichnen links nach rechts
 DrawLine(LCD_WIDTH,0,LCD_WIDTH/2,LCD_HEIGHT); //und andersrum
 Delay1ms(3000);

 ClearScreen();                     
 LCDCls();
 LCDWrite("Software Fonts 1"); //Text auf dem Textdisplay
//Software Fonts. Schreiben ist langsam, daf�r auf einen Pixel genau plazierbar
 SetFont(4);
//Umlaute unter Windows hier im DOS-Modus eintippen !
 LCDSoftText("F16x8a SoftFont gjqy�������",0,0);
 SetFont(5);
 LCDSoftText("F16x8b SoftFont gjqy�������",0,18);
 SetFont(6);
 LCDSoftText("F16x8c SoftFont gjqy�������",0,36);
 Delay1ms(3000);

 ClearScreen();                     
 LCDCls();
 LCDWrite("Software Fonts 2"); //Text auf dem Textdisplay
//Software Fonts. Schreiben ist langsam, daf�r auf einen Pixel genau plazierbar
 SetFont(1);
//Umlaute unter Windows hier im DOS-Modus eintippen !
 LCDSoftText("F8x6 SoftFont gjqy�������",0,0);
 SetFont(2);
 LCDSoftText("F8x8a SoftFont gjqy�������",0,9);
 SetFont(3);
 LCDSoftText("F8x8b SoftFont gjqy�������",0,18);
 SetFont(7);
 LCDSoftText("F6x4fv SoftFont gjqy�������",0,27);
 SetFont(8);
 LCDSoftText("F6x5fv SoftFont gjqy�������",0,36);
 SetFont(9);
 LCDSoftText("F8x6fv SoftFont gjqy�������",0,45);
 SetFont(10);
 LCDSoftText("F8x8fv SoftFont gjqy�������",0,54);
 Delay1ms(3000);

//�bersicht aller Fonts anzeigen
 LCDCls();
 LCDWrite("Fonts anzeigen"); //Text auf dem Textdisplay
 for(i=1; i<11; i++)
  {
   ShowSoftFont(i);
   Delay1ms(3000);
  }

  } //Endlosschleife
}

void InitHardware()
{

 IE=0;    //Ersma alle Interrupts aus
 P1=0;    //Flash Bank0 w�hlen
 LED_ON(); //Rote LED als Kennzeichen kein Empfang

 TCON=0;    //Alle Timer Stop

//Ergibt alle 256us einen Timer0 Interrupt bei 11.059MHz
//alle 128us bei X2 aktiv
 TL0=0;     //Timer0 Low l�schen
 TH0=0;     //Timer0 High l�schen

 TMOD=0x21; //Timer1 8Bit AutoReload,Start/Stop �ber TCON
            //Timer0 16Bit

 TR0=1;   //Timer0 starten
 ET0=1;    /* enable timer 0 interrupt    */

 EA = 1;    /* global interrupt enable     */

 CKCON=0x01; //Achtung: doppelter CPU-Clock ! USART,Timer usw laufen
          //dann auch doppelt so schnell ! Nur f�r 80C32X2 Prozessoren.
}

//Timer0 Interruptroutine
void Timer0Int(void) interrupt 1 using 2
{
 timeout++; //Endlosschleifen verhindern durch Timeoutz�hler
}

//Timer1 Interruptroutine
/*
void Timer1Int(void) interrupt 3 using 3
{
}
*/

//F�r time>2 und 11.059MHz
//Nicht besonders genau
//time maximal 65535
void Delay1ms(unsigned int time)
{
 unsigned int i,j;
 for(j=0; j<time; j++)
//  for(i=0; i<112; i++);  //11.059MHz 
  for(i=0; i<224; i++);  //11.059MHz und X2 aktiv
}

//F�r kurze Verz�gerungen z.B. LCD-IO
void Delay100us()
{
 unsigned char i;

// i=12; //11.059MHz
 i=24; //11.059MHz und X2 aktiv
 while(i) i--;
}
