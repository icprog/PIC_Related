var searchData=
[
  ['blank',['BLANK',['../glcd__128x64_8h.html#a5aebfba92373e0dc8a76d272bcd8e85d',1,'glcd_128x64.h']]],
  ['boolean',['boolean',['../micro_8h.html#a9c639bd343606632b938f16f4adf516a',1,'micro.h']]],
  ['build',['build',['../struct___version__s.html#ade8dc96ac0239f1d5a9ea07b6954de19',1,'_Version_s']]]
];
