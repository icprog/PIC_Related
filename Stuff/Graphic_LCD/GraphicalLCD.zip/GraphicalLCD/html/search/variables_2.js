var searchData=
[
  ['lcd_5fline',['lcd_line',['../config_8h.html#a153d48ae246cfe09be37279a6e8d3242',1,'config.h']]],
  ['logo',['logo',['../main_8c.html#a5b7005547356828147c1344a3aaa62d9',1,'main.c']]]
];
