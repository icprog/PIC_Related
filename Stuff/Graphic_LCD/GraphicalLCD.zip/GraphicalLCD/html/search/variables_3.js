var searchData=
[
  ['major',['major',['../struct___version__s.html#ac7f7baa7d8f253faab03e21da432505b',1,'_Version_s']]],
  ['minor',['minor',['../struct___version__s.html#ac6290b7c20d9aa1b215e6f9915eb1977',1,'_Version_s']]]
];
