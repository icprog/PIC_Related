var searchData=
[
  ['t0_5fmillis',['t0_millis',['../config_8c.html#a3ce4c538876d29c7b471f22893ed7823',1,'config.c']]],
  ['terminal8x8',['Terminal8x8',['../glcd__font_8h.html#a21b0f3d32a2b033a6bb20ce7159f6e49',1,'glcd_font.h']]],
  ['timer0_5finit',['Timer0_Init',['../config_8c.html#aa3bf395437026195009927604764a69a',1,'Timer0_Init(void):&#160;config.c'],['../config_8h.html#aa3bf395437026195009927604764a69a',1,'Timer0_Init(void):&#160;config.c']]],
  ['true',['TRUE',['../micro_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'micro.h']]]
];
