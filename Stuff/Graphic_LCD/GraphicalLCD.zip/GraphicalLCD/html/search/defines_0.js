var searchData=
[
  ['_5fxtal_5ffreq',['_XTAL_FREQ',['../config_8h.html#a024148e99a7143db044a48216664d03d',1,'config.h']]]
];
