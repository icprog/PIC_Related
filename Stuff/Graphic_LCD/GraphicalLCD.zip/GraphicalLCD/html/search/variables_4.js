var searchData=
[
  ['softver',['SoftVer',['../config_8c.html#a3760e2997bcb918bb90c2d634dfe8ca0',1,'SoftVer():&#160;config.c'],['../config_8h.html#a3760e2997bcb918bb90c2d634dfe8ca0',1,'SoftVer():&#160;config.c']]]
];
