var searchData=
[
  ['boolean',['boolean',['../micro_8h.html#a9c639bd343606632b938f16f4adf516a',1,'micro.h']]]
];
