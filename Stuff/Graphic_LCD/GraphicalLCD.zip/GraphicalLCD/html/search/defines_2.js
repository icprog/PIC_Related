var searchData=
[
  ['chip_5fselect_5factive_5flow',['CHIP_SELECT_ACTIVE_LOW',['../glcd__128x64_8h.html#a596a0c8811d6827a22a3aa353b826001',1,'glcd_128x64.h']]],
  ['clr_5fbit',['CLR_BIT',['../micro_8h.html#abdaed66cef9de3c8ea6362fd9c50f9d1',1,'micro.h']]]
];
