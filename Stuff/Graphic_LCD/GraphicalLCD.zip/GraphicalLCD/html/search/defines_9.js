var searchData=
[
  ['max',['MAX',['../micro_8h.html#aba93bd95f52b3ff4f0daa59676022d1e',1,'micro.h']]],
  ['min',['MIN',['../micro_8h.html#a5030f5bdeea4d6aeaab126e48304d033',1,'micro.h']]]
];
