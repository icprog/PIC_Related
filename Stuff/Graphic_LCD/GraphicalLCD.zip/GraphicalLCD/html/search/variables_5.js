var searchData=
[
  ['t0_5fmillis',['t0_millis',['../config_8c.html#a3ce4c538876d29c7b471f22893ed7823',1,'config.c']]],
  ['terminal8x8',['Terminal8x8',['../glcd__font_8h.html#a21b0f3d32a2b033a6bb20ce7159f6e49',1,'glcd_font.h']]]
];
