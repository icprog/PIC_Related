var searchData=
[
  ['high',['HIGH',['../micro_8h.html#a5bb885982ff66a2e0a0a45a8ee9c35e2',1,'micro.h']]]
];
