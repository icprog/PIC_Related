var searchData=
[
  ['disable_5fchip1',['disable_chip1',['../glcd__128x64_8h.html#ac4caf7e36f29a62435a201993e41a69d',1,'glcd_128x64.h']]],
  ['disable_5fchip2',['disable_chip2',['../glcd__128x64_8h.html#ace49a01f7d6a90d1cb0989e0762135e0',1,'glcd_128x64.h']]],
  ['disable_5fglobal_5fint',['disable_global_int',['../config_8h.html#aafb7b5fb8490dee8f247656e21259a09',1,'config.h']]]
];
