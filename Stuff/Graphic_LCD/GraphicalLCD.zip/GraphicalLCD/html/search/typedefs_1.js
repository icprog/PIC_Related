var searchData=
[
  ['s16_5ft',['s16_t',['../micro_8h.html#acf46f4df0ebab84edebcb69967fdf86b',1,'micro.h']]],
  ['s32_5ft',['s32_t',['../micro_8h.html#a10f9a3d7baef58ccc23228c3bd29c1fb',1,'micro.h']]],
  ['s8_5ft',['s8_t',['../micro_8h.html#a9cd1d7891fe315de1201e2c6e45f4f57',1,'micro.h']]]
];
