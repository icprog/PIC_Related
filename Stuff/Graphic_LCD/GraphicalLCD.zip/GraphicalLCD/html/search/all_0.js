var searchData=
[
  ['_5fversion_5fs',['_Version_s',['../struct___version__s.html',1,'']]],
  ['_5fxtal_5ffreq',['_XTAL_FREQ',['../config_8h.html#a024148e99a7143db044a48216664d03d',1,'config.h']]]
];
