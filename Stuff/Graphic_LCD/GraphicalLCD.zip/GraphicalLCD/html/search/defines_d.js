var searchData=
[
  ['true',['TRUE',['../micro_8h.html#aa8cecfc5c5c054d2875c03e77b7be15d',1,'micro.h']]]
];
