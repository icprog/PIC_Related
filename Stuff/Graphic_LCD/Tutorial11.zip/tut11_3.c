#include <pic.h>				// pic specific identifiers
#include <stdio.h>
#define _XTAL_FREQ  4000000		// Xtal speed
__CONFIG(0x393A);				// Config bits

#define LCD_PORT PORTB			// constants
#define LCD_TRIS TRISB			//
#define LCD_RS 	RB4
#define LCD_RW	RB6
#define LCD_E	RB7

		// Required prototypes.. each function needs to be declared
		// if called BEFORE definition.

void LCD_init(void), LCD_cmd(unsigned char ch);
void LCD_goto(char line, char column), LCD_clr(void);
void LCD_cur(unsigned char ch), pulse_E(void), LCD_hex(int value);
void LCD_char(unsigned char ch), LCD_charD(unsigned char ch);
void LCD_printC(const char *str), LCD_printR(char *str);
void delayMs(int x), InitADC(void);
int ReadADC(unsigned char ch);

unsigned char LCDbuffer[17];

void main(void)						// program entry
	{
	int index = 0;
	int number = 0;					// new counting variable
	LCD_TRIS = 0b00000000;			// Led port as outputs
	__delay_ms(150);				// let LCD stabilise
	LCD_init();
	InitADC();						// Initalise screen
	LCD_goto(1,0);					// line 1.
	LCD_printC("Tutorial 11.3");
	while(1)						// endless Loop
		{
		LCD_goto(2,0);
		number = ReadADC(0);
		sprintf(LCDbuffer,"%d.%02dV   ",number/100,number%100);
		LCD_printR(LCDbuffer);		// again.. using sprintf
		delayMs(40);				// to format our output
		}
	}

void InitADC()
	{								// Set ADCON0 & 1
	ADCON0 = 0b10000001;			// FOSC/32 and adc on
	ADCON1 = 0b10000101;			// Right justified an1 and an2
	}								// vref on an3 (req for nigels board)

int ReadADC(unsigned char ch)
	{
	int ret = 0;
	ADCON0 = 0b10000001 + (ch<<3);	// set channel to read
	delayMs(5);
	GODONE = 1;						// start conversion
   	while(GODONE);					// wait for conversion
   	ret =  (ADRESH & 0x3) << 8;		// get
   	ret +=	ADRESL;					// result
	return ret;
	}

void delayMs(int x)
	{
	while(x--)
		__delay_ms(1);
	}

void LCD_printC(const char * str)	// This passes the start a ROM character array
	{								// by default the pointer points to data section
	while(*str != 0)				// while the character pointed to isn't 0
		LCD_char(*str++);			// print out the character, then increment
	}								// the pointer down the array

void LCD_printR(char * str)	 		// This passes the start of a RAM character array
	{								// by default the pointer points to data section
	while(*str != 0)				// while the character pointed to isn't 0
		LCD_char(*str++);			// print out the character, then increment
	}								// the pointer down the array
void LCD_init()
	{
	LCD_cmd(0x20);					// 4 bit
	LCD_cmd(0x28);					// display shift
	LCD_cmd(0x6);					// character mode
	LCD_cmd(0xc);					// display on / off and cursor
	LCD_clr();						// clear display
	}
void LCD_goto(char line, char column)		// combines line and lineW
	{
	unsigned char data = 0x80;				// default to 1
	if(line == 2)data = 0xc0;				// change to 2
	data += column;							// add in  column
	LCD_cmd(data);
	}

void LCD_clr()
	{
	LCD_cmd(1);								// Clr screen
	}

void LCD_cur(char on)
	{
	unsigned char cur = 0xc;				// cursor off
	if(on) cur = 0xd;						// cursor on
	LCD_cmd(cur);
	}

void LCD_cmd(unsigned char ch)
	{
	LCD_PORT = ch >> 4 & 0xf;			// write high nibble
	LCD_RS = 0;
	pulse_E();
	delayMs(2);
	LCD_PORT = ch & 0xf;				// write low nibble
	LCD_RS = 0;
	pulse_E();
	delayMs(2);
	}

void LCD_charD(unsigned char ch)
	{
	ch+=0x30;
	LCD_char(ch);						// convert to ascii
	}

void LCD_char(unsigned char ch)
	{
	LCD_PORT = ch >> 4 & 0xf;			// High nibble
	LCD_RS = 1;
	pulse_E();
	LCD_PORT = ch & 0xf;				// low nibble
	LCD_RS = 1;
	pulse_E();
	delayMs(2);
	}

void pulse_E()
	{
	LCD_E = 1;
	__delay_us(1);
	LCD_E = 0;
	}