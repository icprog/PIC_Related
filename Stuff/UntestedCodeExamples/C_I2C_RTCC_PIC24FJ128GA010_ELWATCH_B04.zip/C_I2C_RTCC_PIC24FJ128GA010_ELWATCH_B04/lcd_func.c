// File Name    : lcd_func.c 
// PIC24 family, C language. 
// Dependencies : p24fj128ga010.h, delay.h, lcd.h 
// Processor    : PIC24FJ128GA010    
// Hardware     : Explorer 16 demo board, Truly TSB1G7000 LCD
// I.D.E.       : MPLAB + C30 compiler   
/***********************************************************************
* Company:         Microchip Technology, Inc.
*
* Software License Agreement
*
* "Microchip Technology Inc." ("Microchip") licenses this software to you 
* solely for use with Microchip's Serial RTCC products.  
* The software is owned by Microchip and/or its licensors, and is protected 
* under applicable copyright laws.  All rights reserved.
*
* SOFTWARE IS PROVIDED "AS IS."  MICROCHIP AND ITS LICENSOR EXPRESSLY 
* DISCLAIM ANY WARRANTY OF ANY KIND, WHETHER EXPRESS OR IMPLIED, STARTLUDING 
* BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS 
* FOR A PARTICULAR PURPOSE,OR NON-INFRINGEMENT. IN NO EVENT SHALL MICROCHIP 
* AND ITS LICENSORS BE LIABLE FOR ANY STARTIDENTAL, SPECIAL, INDIRECT OR 
* CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, HARM TO YOUR EQUIPMENT, 
* COST OF PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY 
* CLAIMS BY THIRD PARTIES (STARTLUDING BUT NOT LIMITED TO ANY DEFENSE 
* THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER SIMILAR COSTS."
*
* Author            Date          Comment
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
* Eugen Ionescu     10/16/2011    Initial release for Explorer 16 demo board (Truly TSB1G7000 LCD)
*
 *************************************************************************************************/
#include "p24fj128ga010.h"
#include "delay.h"
#include "lcd.h" 
//................................................................................................
//                          LCD LOW LEVEL FUNCTIONS 
//................................................................................................
// The below function initializes the LCD: 8 BITS, 2 LINES, DISPLAY ON, CURSOR/BLINK OFF, 
//                                         INCREMENT MODE, SHIFT RIGHT  
//................................................................................................   
void ini_lcd(void){             // initialization of the LCD 
delay15ms(); delay15ms()      ; // wait Vdd reaches nnVdc before proceeding with LCD initialization		
// set initial states for the data & control pins 
DATA &= 0xFF00                ; // clear RE0-RE7 (data pins)
RW = 0                        ; // R/W = low
RS = 0                        ; // RS  = low
E  = 0                        ; // E   = low
// set data & control pins to outputs 
TRISE &= 0xFF00               ;	// RE0 - RE7 = output (data pins)
RW_TRIS = 0                   ; // RW  = output
RS_TRIS = 0                   ; // RS  = output
E_TRIS = 0                    ; // E   = output
wrcmnd_lcd(FUNCTION+DL8+LINES); // function set (data length = 8 bits, 2 lines)
wrcmnd_lcd(DISPLAY+D_ON)      ; // Display = ON, cursor & blink = OFF 
wrcmnd_lcd(MODE+SHR)      ;	  }	// entry mode set (inc mode, shift right)
//....................................................................................
// 			 	Writes a command into the LCD
//....................................................................................
void wrcmnd_lcd(unsigned char cmd){ // writting a command into the LCD 
DATA &= 0xFF00                ; // clear RE0-RE7 (data pins)
DATA |= cmd                   ; // send command byte to LCD
RW = 0                        ; // ensure RW is 0
RS = 0                        ;	// and RS is 0
E = 1                         ; // toggle E signal
Nop()  ;   Nop()  ;   Nop()   ; // short delay         
E = 0                         ;	// clear E signal
delay5ms()        ;           } // 5ms delay
//....................................................................................
// 					Writes a data byte into the LCD
//....................................................................................
void wrdata_lcd(unsigned char data){ // writting a data byte into the LCD 
RW = 0                        ;  // ensure RW is 0
RS = 1                        ;  // assert register select to 1
DATA &= 0xFF00                ;  // clear RE0-RE7 (data pins)
DATA |= data                  ;  // send data byte to lcd
E  = 1                        ;  // set E signal				
Nop()   ;   Nop()   ;   Nop() ;  // short delay 
E  = 0                        ;  // toggle E signal
RS = 0                        ;  // negate register select to 0
delay200us() ; delay200us() ; }  // 400usec delay
//....................................................................................
// 			Clears the LCD, cursor left up corner on first row
//....................................................................................
void clr_lcd(void){              // clearing the LCD 
wrcmnd_lcd(CLEAR)             ;  // CLEAR command
delay15ms()                ;  }  // 15ms delay
//....................................................................................
// 				Turns back cursor with 'pos' positions
//....................................................................................
void back_lcd(unsigned char pos){// turning the cursor back, 'pos' positions 
while(pos){                      // for 'pos' positions
wrcmnd_lcd(CD_SHIFT);pos--; } }  // shift left the crusor     
//....................................................................................
// 					Deletes back 'pos' characters
//....................................................................................
void del_lcd(unsigned char pos){ // deleting back 'pos' characters 
unsigned char k = 0           ;  // loop counter 
wrcmnd_lcd(DISPLAY+D_ON)      ;  // CURSOR = OFF, Blink = ON, DISPLAY ON  
back_lcd(pos)                 ;	 // shift left cursor for 'pos' positions
k=pos                         ;  // init the loop counter 
while(pos){                      // for 'pos' positions, 
wrdata_lcd(' ')  ;  pos--  ;  }  // delete 'pos' characters
back_lcd(k);					 // shift left cursor for 'pos' positions
wrcmnd_lcd(DISPLAY+D_ON+C_ON);}	 // display & cursor & blink = ON 
//****************** LCD HIGH LEVEL FUNCTIONS ****************************************
//....................................................................................
// 		  		    Writes a string into the LCD
//....................................................................................
void wrstr_lcd(char *str){       // writting a string into the LCD 
while(*str){         		   	 // loop till the end of the string  
wrdata_lcd(*str) ; str++  ; } }  // display the character   			  
//.....................................................................................
// 		    		 Writes a number into the LCD
//.....................................................................................
void wrnr_lcd(unsigned long k){  // writting a number into the LCD            
unsigned char v[12]			  ;  // array to store the digits of a number
int i=0						  ;  // counter for a digit inside the number 
if (k>0){                        // if the number > 0 
	while (k){                   // find the digits' number until it becomes 0          
		v[i]=(k%10);       		 // store the digit
		k=k/10                ;  // divide the number by 10 (eliminate the last digit)
		i++				;     }  // increment the digit counter
	i--						  ;  // decrement the digit counter (the vector has i-1 elements)
for (;i>=0;i--)  wrdata_lcd((v[i])+ASCII_DIGIT);} // display the number on LCD
else wrdata_lcd(0+ASCII_DIGIT);} // display a '0' value 
                   
                                        
