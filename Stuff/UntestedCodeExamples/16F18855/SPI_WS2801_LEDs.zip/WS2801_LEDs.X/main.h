/* 
 * File:   main.h
 * Author: abochmann@transim.com
 *
 * Created on 2/20/2016 5:35:34 AM UTC
 * "Created in MPLAB Xpress"
 */

#ifndef MAIN_H
#define	MAIN_H

typedef enum
{
    RED,
    GREEN,
    BLUE
} color_t;

uint8_t getColor(color_t color);

#endif	/* MAIN_H */
