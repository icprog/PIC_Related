/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using MPLAB(c) Code Configurator

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  MPLAB(c) Code Configurator - v3.00
        Device            :  PIC16F18855
        Driver Version    :  2.00
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.35
        MPLAB             :  MPLAB X 3.20
*/

/*
Copyright (c) 2013 - 2015 released Microchip Technology Inc.  All rights reserved.

Microchip licenses to you the right to use, modify, copy and distribute
Software only when embedded on a Microchip microcontroller or digital signal
controller that is integrated into your product or third party product
(pursuant to the sublicense terms in the accompanying license agreement).

You should refer to the license agreement accompanying this Software for
additional information regarding your rights and obligations.

SOFTWARE AND DOCUMENTATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION, ANY WARRANTY OF
MERCHANTABILITY, TITLE, NON-INFRINGEMENT AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL MICROCHIP OR ITS LICENSORS BE LIABLE OR OBLIGATED UNDER
CONTRACT, NEGLIGENCE, STRICT LIABILITY, CONTRIBUTION, BREACH OF WARRANTY, OR
OTHER LEGAL EQUITABLE THEORY ANY DIRECT OR INDIRECT DAMAGES OR EXPENSES
INCLUDING BUT NOT LIMITED TO ANY INCIDENTAL, SPECIAL, INDIRECT, PUNITIVE OR
CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF PROCUREMENT OF
SUBSTITUTE GOODS, TECHNOLOGY, SERVICES, OR ANY CLAIMS BY THIRD PARTIES
(INCLUDING BUT NOT LIMITED TO ANY DEFENSE THEREOF), OR OTHER SIMILAR COSTS.
 */

#include "mcc_generated_files/mcc.h"
#include "main.h"

// This variable holds the current color
static char rgb[3];

// This variable is used to turn the LED off
static char off[3] = {0, 0, 0};

// Sets the static rgb variable to the color from the color_t enum
void setColor(color_t color) {
    rgb[0] = 0;
    rgb[1] = 0;
    rgb[2] = 0;
            
    switch(color) {
        case RED: rgb[0] = 255; break;
        case GREEN: rgb[1] = 255; break;
        case BLUE: rgb[2] = 255; break;
    }
}

/*
                         Main application
 */
void main(void)
{
    // initialize the device
    SYSTEM_Initialize();

    // Number of LEDs
    int ledCount = 38;
    
    // Index of current LED
    int curLed = 0;
    
    // Set initial color
    color_t curColor = RED;
    setColor(curColor);
    
    while (1) {
        // Loop through all LEDs and set the color of each one
        for(int i = 0; i < ledCount; i++) {
            
            if(curLed == i) {
                // Right now only one LED is on. We send the color for this LED over SPI
                SPI1_Exchange8bitBuffer(rgb, 3, NULL);
            }
            else {
                // All other LEDs will be off
                SPI1_Exchange8bitBuffer(off, 3, NULL);
            }
        }
        
        curLed++;
        
        // Change color and reset current LED index after reaching the last LED
        if(curLed == ledCount) {
            curLed = 0;
            
            switch(curColor) {
                case RED:
                    curColor = GREEN;
                    break;
                case GREEN:
                    curColor = BLUE;
                    break;
                case BLUE:
                    curColor = RED;
                    break;
            }
            
            setColor(curColor);
        }
        
        // This will be the delay between the LED change
        // WS2812 also needs that delay to flush the received data
        __delay_ms(25);
    }
}
/**
 End of File
*/