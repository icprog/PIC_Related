mcc generated files.
