Some info abut the code.

things to add or fix
1) store set point in eeprom
2) avaeage 4 temp readings
3) fix display flicker

heater_min_on_tmr
heater_max_on_tmr
heater_rest_tmr

temperature sample rate

