# Simple-Electronic-Thermostat
Code for a simple electronic thermostat based on a PIC16F18855.
See my blog post at http://af6ea.blogspot.com/2017/02/simple-electronic-thermostat.html

See the code directory for the code available at this time.
