git add *.c
git add *.h
git add README.md
git add LCD2\*
git add .gitignore
git add gitadd.sh
