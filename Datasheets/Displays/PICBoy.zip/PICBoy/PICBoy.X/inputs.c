#include "inputs.h"
#include "plib.h"


#define NoPush 0
#define MaybePush 1
#define Pushed 2
#define MaybeNoPush 3

int calib_horz;
int calib_vert;
int a_press;
int b_press;
int joy_press;

static int press1, press2;
static int PushState1 = 0, PushState2 = 0;

void read_A(int game) {
    press1 = mPORTAReadBits(BIT_3) > 0;
    switch (PushState1) {
        case NoPush:
            if (press1) {
                PushState1 = MaybePush;
            } else PushState1 = NoPush;
            break;
        case MaybePush:
            if (press1) {
                PushState1 = Pushed;
                //find out what key was pressed
            } else PushState1 = NoPush;
            break;

        case Pushed:
            if (press1) {
                PushState1 = Pushed;
            } else {
                PushState1 = MaybeNoPush;
            }
            break;

        case MaybeNoPush:
            if (press1) PushState1 = Pushed;
            else PushState1 = NoPush;
            break;
    }
    a_press = game ? (PushState1 == Pushed) : (PushState1 == MaybePush);
}

void read_B(int game) {
    press2 = mPORTBReadBits(BIT_10) > 0;
    switch (PushState2) {
        case NoPush:
            if (press2) {
                PushState2 = MaybePush;
            } else PushState2 = NoPush;
            break;
        case MaybePush:
            if (press2) {
                PushState2 = Pushed;
                //find out what key was pressed
            } else PushState2 = NoPush;
            break;

        case Pushed:
            if (press2) {
                PushState2 = Pushed;
            } else {
                PushState2 = MaybeNoPush;
            }
            break;

        case MaybeNoPush:
            if (press2) PushState2 = Pushed;
            else PushState2 = NoPush;
            break;
    }
    b_press = game ? (PushState2 == Pushed) : (PushState2 == MaybePush);
}

void read_joy() {
    joy_press = mPORTBReadBits(BIT_8) > 0;
}

void calibrate_joystick() {
    int i;
    for (i = 0; i < 1000000; i++);
    calib_horz = ReadADC10(0); // read the result of channel 9 conversion from the idle buffer
    calib_vert = ReadADC10(1);
}

int interpret_adc(int joy_adc) {
    int shifted_adc = joy_adc >> 7;
    if (shifted_adc == 4)
        return 3;
    return shifted_adc < 0 ? shifted_adc + 1 : shifted_adc;
}