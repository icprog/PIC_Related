extern int calib_horz;
extern int calib_vert;
extern int a_press;
extern int b_press;
extern int joy_press;

void read_A();
void read_B();
void read_Joy();
void calibrate_joystick();

