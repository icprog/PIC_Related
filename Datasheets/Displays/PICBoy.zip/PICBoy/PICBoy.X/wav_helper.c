#include "wav_helper.h"
#include "tft_gfx.h"
#define SYS_FREQ 40000000
//#include "config.h"
//#include "pt_cornell_1_2_1.h"

static UINT8 receiveBuffer[100];

UINT8 getWavHeader(FSFILE * pointer) {

    if (FSfread(receiveBuffer, 1, 44, pointer) != 44) {
        return incorrectHeaderSize;
    }

    if ( (receiveBuffer[0] != 'R') |
            (receiveBuffer[1] != 'I') |
            (receiveBuffer[2] != 'F') |
            (receiveBuffer[3] != 'F') ) {
        return riff;
    }

    if ( (receiveBuffer[8] != 'W') |
            (receiveBuffer[9] != 'A') |
            (receiveBuffer[10] != 'V') |
            (receiveBuffer[11] != 'E') ) {
        return wav;
    }

    if ( (receiveBuffer[12] != 'f') |
            (receiveBuffer[13] != 'm') |
            (receiveBuffer[14] != 't') ) {
        return fmt;
    }

    if (receiveBuffer[20] != 1) {
        return notPCM;
    }

    return allGood;         // no errors

}

void getParameters(UINT8 * bitsPerSample, UINT8 * numberOfChannels,
                        UINT32 * dataSize, UINT32 * sampleRate,
                        UINT32 * blockAlign) {
    *bitsPerSample = receiveBuffer[34];
    *numberOfChannels = receiveBuffer[22];
    *sampleRate = (receiveBuffer[25] << 8) | receiveBuffer[24];

    *dataSize = (receiveBuffer[43] << 24) |
        (receiveBuffer[42] << 16) |
        (receiveBuffer[41] << 8) |
        receiveBuffer[40];
    
    *blockAlign = receiveBuffer[32];
}

void setupDAC(){
    CVREFOpen(CVREF_ENABLE | CVREF_OUTPUT_ENABLE | CVREF_RANGE_LOW | CVREF_SOURCE_AVDD | CVREF_STEP_0);
//    CVRCON_setup = CVRCON;
    
}

void setupDMA(int chn, const char* filename){
    INTDisableInterrupts();
    SearchRec rec;
    UINT8 attributes = ATTR_MASK; // file can have any attributes
    FSFILE * wav_file;
    UINT8 bitsPerSample = 0;
    UINT32 sampleRate = 0;
    UINT8 numberOfChannels = 0;
    UINT32 dataSize = 0;
    UINT32 blockAlign = 0;
    int y = 0;
    char buffer[60];
    if (!FSInit()) {
        tft_writeString("FAILURE");
        while (1);
    }
    wav_file = FSfopen(filename, FS_READ);
    if(wav_file != NULL){
        if (getWavHeader(wav_file) == allGood) {
            getParameters(&bitsPerSample, &numberOfChannels, &dataSize, &sampleRate, &blockAlign);
        }
    }
    if(wav_file == NULL){
        tft_writeString(filename);
    }
    volatile UINT8 *ptr;
    if(chn == 0)
        ptr = SOUND0;
    else
        ptr = SOUND1;
    UINT16 retBytes = FSfread((void*)ptr, 1, SOUND_SIZE*blockAlign, wav_file);
    FSfclose(wav_file);
    int k = 0;
    for (k = 0; k < retBytes; k++) {
        ptr[k] |= 0x8060;
    }
    // We enable the AUTO option, we'll keep repeating the sam transfer over and over.
    DmaChnOpen(chn, 0, DMA_OPEN_DEFAULT);

    // set the transfer parameters: source & destination address, source & destination size, number of bytes per event
    // Setting the last parameter to one makes the DMA output one byte/interrupt
    DmaChnSetTxfer(chn, (void*) ptr, (void*) &CVRCON, retBytes, 1, 1);

    // set the transfer event control: what event is to start the DMA transfer
    // In this case, timer2
    DmaChnSetEventControl(chn, DMA_EV_START_IRQ(_TIMER_2_IRQ));
    OpenTimer2(T2_ON | T2_SOURCE_INT | T2_PS_1_1, (SYS_FREQ / (sampleRate)) - 1);
    INTEnableSystemMultiVectoredInt();
}
