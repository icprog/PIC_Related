////////////////////////////////////
// clock AND protoThreads configure!
// You MUST check this file!
#include "config.h"
// threading library
#include "pt_cornell_1_2_1.h"

////////////////////////////////////
// graphics libraries
#include "tft_master.h"
#include "tft_gfx.h"
#include "inputs.h"
#include "MDD_includes/FSIO.h"
#include <GenericTypeDefs.h>
#include "wav_helper.h"
// need for rand function
////////////////////////////////////
#define SYS_FREQ 50000000
#define SOUND_SAMPLE_RATE 8820
#define RADIUS 1   // ball radius
#define ASTEROID_RADIUS 8
#define HAZARD_RADIUS 20
#define SHIP_RADIUS 10
#define MAX_BALLS 10 // maximum balls to animate
#define MAX_BULLETS 30
#define MAX_HAZARDS 10
#define FPS 30   //starting framrate
#define SPF (1000/FPS) // starting seconds per frame
// Rate in Frames per ball
#define dmaChn0 0 // the DMA channel to use for -1 score
#define dmaChn1 1 // the DMA channel to use for +1 score
#define SEED 101 // random 
#define ASTEROIDS 0
#define RACING 1
#define MAX_SPEED 15
#define MIN_SPEED 7

#define CAR_HEIGHT 15
#define CAR_WIDTH 10
// string buffer
char buffer[60];



volatile UINT8 txt[10];
// === thread structures ============================================
// thread control structs
// note that UART input and output are threads
static struct pt pt_timer, pt_adc, pt_compute_asteroids, pt_ship, pt_launcher, pt_track, pt_car, pt_sd;

// === Pull up/down =================================================
// PORT B
#define EnablePullDownB(bits) CNPUBCLR=bits; CNPDBSET=bits;
#define DisablePullDownB(bits) CNPDBCLR=bits;
#define EnablePullUpB(bits) CNPDBCLR=bits; CNPUBSET=bits;
#define DisablePullUpB(bits) CNPUBCLR=bits;
//PORT A
#define EnablePullDownA(bits) CNPUACLR=bits; CNPDASET=bits;
#define DisablePullDownA(bits) CNPDACLR=bits;
#define EnablePullUpA(bits) CNPDACLR=bits; CNPUASET=bits;
#define DisablePullUpA(bits) CNPUACLR=bits;


// === the fixed point macros ========================================
typedef signed int fix16;
#define multfix16(a,b) ((fix16)(((( signed long long)(a))*(( signed long long)(b)))>>16)) //multiply two fixed 16:16
#define float2fix16(a) ((fix16)((a)*65536.0)) // 2^16
#define fix2float16(a) ((float)(a)/65536.0)
#define fix2int16(a)    ((int)((a)>>16))
#define int2fix16(a)    ((fix16)((a)<<16))
#define divfix16(a,b) ((fix16)((((signed long long)(a)<<16)/(b)))) 
#define sqrtfix16(a) (float2fix16(sqrt(fix2float16(a)))) 
#define absfix16(a) abs(a)

// ball struct for position, velocity and hit count
//                        0, 30,  60,  90, 120, 150, 180, 210,  240,  270, 300,  330
const float sin_table[] = {0, .5, .866, 1, .866, .5, 0, -.5, -.866, -1, -.866, -.5};
#define SIN_TABLE_SIZE 12
#define sin(i) sin_table[i % SIN_TABLE_SIZE]
#define cos(i) sin_table[((i + 3) % SIN_TABLE_SIZE)]

UINT32 spicon_fs;
UINT32 spicon2_fs;

void SD_Config() {//resets config and status registers so that SD card transaction can occur
    SPI2CON = spicon_fs;
    SPI2CON2 = spicon2_fs;
    SPI2STAT = 0;
}

typedef struct bullet {
    fix16 x;
    fix16 y;
    fix16 vx;
    fix16 vy;
    char active;
    int hit;
} bullet_t;

typedef struct asteroid {
    fix16 x;
    fix16 y;
    fix16 vx;
    fix16 vy;
    char active;
    int color;
} asteroid_t;

typedef struct ship {
    fix16 x;
    fix16 y;
    fix16 vx;
    fix16 vy;
    char rotation;
    int lives;
    int score;
    fix16 speed;
} ship_t;
// which game is selected
volatile char game;
//current game fps
volatile int fps;
//inverse fps currently
volatile int count;
volatile int inv_fps;
volatile int score = 0;
volatile int rumble = 0;
volatile int balls_to_release = 1;
volatile int game_over = 0;
const unsigned int lanes[6] = {30, 82, 134, 186, 238, 290};
static ship_t ship;
//drag coefficient
fix16 drag = float2fix16(.001);

static char asteroid_index;
asteroid_t asteroids[MAX_HAZARDS];

// initialize hazards for racing

void init_hazards() {
    int i;
    for (i = 0; i < MAX_HAZARDS; i++) {
        asteroid_t *asteroid = &asteroids[i];
        asteroid->active = 0;
        int color = rand() % 7;
        switch (color) {
            case 0:
                asteroid->color = ILI9340_WHITE;
                break;
            case 1:
                asteroid->color = ILI9340_YELLOW;
                break;
            case 2:
                asteroid->color = ILI9340_RED;
                break;
            case 3:
                asteroid->color = ILI9340_CYAN;
                break;
            case 4:
                asteroid->color = ILI9340_GREEN;
                break;
            case 5:
                asteroid->color = ILI9340_BLUE;
                break;
            case 6:
                asteroid->color = ILI9340_MAGENTA;
                break;
            default:
                asteroid->color = ILI9340_WHITE;
                break;
        }
    }

}

// create a hazard to draw, make it active

void spawn_hazard(char i) {
    asteroid_t *asteroid = &asteroids[i];
    asteroid->x = int2fix16(lanes[rand() % 6]);
    asteroid->y = int2fix16(0);
    asteroid->vy = ship.speed;
    asteroid->vx = int2fix16(0);
    asteroid->active = 1;
}

//modify speed of all hazards

void move_hazards() {
    int i;
    for (i = 0; i < MAX_HAZARDS; i++) {
        asteroid_t *asteroid = &asteroids[i];
        if (asteroid->active != 1)
            continue;
        asteroid->vy = ship.speed;
    }
}

//setup all asteroids

void init_asteroids() {
    int i;
    for (i = 0; i < MAX_BALLS; i++) {
        asteroid_t *asteroid = &asteroids[i];
        //        if (asteroid->active == 1 && !game_over) {
        //            continue;
        //        }
        int mult = (rand() % 2 == 0) ? 1 : -1;
        asteroid->x = (mult == 1) ? int2fix16(319) : int2fix16(0);
        asteroid->y = int2fix16((rand() % 239));
        asteroid->vx = int2fix16(mult * (rand() % 3 + 1));
        asteroid->vy = int2fix16(mult * (rand() % 3 + 1));
        asteroid->active = 1;
        int color = rand() % 7;
        switch (color) {
            case 0:
                asteroid->color = ILI9340_WHITE;
                break;
            case 1:
                asteroid->color = ILI9340_YELLOW;
                break;
            case 2:
                asteroid->color = ILI9340_RED;
                break;
            case 3:
                asteroid->color = ILI9340_CYAN;
                break;
            case 4:
                asteroid->color = ILI9340_GREEN;
                break;
            case 5:
                asteroid->color = ILI9340_BLUE;
                break;
            case 6:
                asteroid->color = ILI9340_MAGENTA;
                break;
            default:
                asteroid->color = ILI9340_WHITE;
                break;
        }
    }
}

//reset an asteroid

void init_asteroid(int ind) {
    asteroid_t *asteroid = &asteroids[ind];
    if (asteroid->active == 1) {
        return;
    }
    int mult = (rand() % 2 == 0) ? 1 : -1;
    asteroid->x = (mult == 1) ? int2fix16(319) : int2fix16(0);
    asteroid->y = int2fix16((rand() % 239));
    asteroid->vx = int2fix16(mult * (rand() % 3 + 1));
    asteroid->vy = int2fix16(mult * (rand() % 3 + 1));
    asteroid->active = 1;
}

//draw all asteroids or hazards

void draw_asteroids() {
    // make struct, size reduces when hit
    int i;
    //radius of hazard different from asteroid
    int radius = (game == RACING) ? HAZARD_RADIUS : ASTEROID_RADIUS;
    if (rumble != 0) {
        rumble--;
    }
    char max = (game == ASTEROIDS) ? MAX_BALLS : MAX_HAZARDS;
    //loop through all objects
    for (i = 0; i < max; i++) {
        //check game over condition
        if (ship.lives <= 0) break;
        asteroid_t *asteroid = &asteroids[i];
        if (asteroid->active != 1)
            continue;
        // erase old position
        tft_drawCircle(fix2int16(asteroid->x), fix2int16(asteroid->y), radius, ILI9340_BLACK);
        fix16 dx = absfix16(ship.x - asteroid->x);
        fix16 dy = absfix16(ship.y - asteroid->y);
        // possible collision
        if (fix2int16(dx) <= (radius + SHIP_RADIUS) && fix2int16(dy) <= (radius + SHIP_RADIUS)) {
            fix16 sq_mag_rij = multfix16(dx, dx) + multfix16(dy, dy);
            // can't divide by zero  
            if (sq_mag_rij == 0) {
                continue;
            }//confirmed collision
            else if (fix2int16(sq_mag_rij) <= 4 * (radius + SHIP_RADIUS)* (radius + SHIP_RADIUS)) {
                ship.lives--;
                rumble = 5;
                asteroid->active = 0;
                if (game == ASTEROIDS) {
                    init_asteroid(i);
                } else {
                    return;
                }
                continue;
            }
        }
        // move position
        asteroid->x = asteroid->x + asteroid->vx;
        asteroid->y = asteroid->y + asteroid->vy;
        // wrap around code
        if (game == ASTEROIDS) {
            if (asteroid->x > int2fix16(320))
                asteroid->x = int2fix16(0);
            else if (asteroid->x < int2fix16(0))
                asteroid->x = int2fix16(320);
            else if (asteroid->y < int2fix16(0))
                asteroid->y = int2fix16(240);
            else if (asteroid->y > int2fix16(240))
                asteroid->y = int2fix16(0);
        } else {
            //check if hazard has reached bottom of screen
            if (asteroid->y > int2fix16(240)) {
                asteroid->active = 0;
                return;
            }
        }
        tft_drawCircle(fix2int16(asteroid->x), fix2int16(asteroid->y), radius, asteroid->color);
    }
}
static int old_x1 = 0, old_x2 = 0, old_x3 = 0, old_y1 = 0, old_y2 = 0, old_y3 = 0;
// draw ship or car
void draw_ship(ship_t* ship) {
    if (game == ASTEROIDS) {
        tft_drawTriangle(old_x1, old_y1, old_x2, old_y2, old_x3, old_y3, ILI9340_BLACK);
        fix16 x = ship->x;
        fix16 y = ship->y;
        unsigned char rotation = ship->rotation;
        // do rotation matrix
        fix16 x1 = x + float2fix16(6 * sin(rotation));
        fix16 y1 = y + float2fix16(-6 * cos(rotation));
        fix16 x2 = x + float2fix16(-5 * cos(rotation) - 6 * sin(rotation));
        fix16 y2 = y + float2fix16(-5 * sin(rotation) + 6 * cos(rotation));
        fix16 x3 = x + float2fix16(5 * cos(rotation) - 6 * sin(rotation));
        fix16 y3 = y + float2fix16(5 * sin(rotation) + 6 * cos(rotation));
        old_x1 = fix2int16(x1);
        old_x2 = fix2int16(x2);
        old_x3 = fix2int16(x3);
        old_y1 = fix2int16(y1);
        old_y2 = fix2int16(y2);
        old_y3 = fix2int16(y3);
        tft_drawTriangle(fix2int16(x1), fix2int16(y1), fix2int16(x2), fix2int16(y2), fix2int16(x3), fix2int16(y3), ILI9340_WHITE);
    } else {
        // just draw the car
        tft_drawRoundRect(old_x1, old_y1, CAR_WIDTH, CAR_HEIGHT, RADIUS, ILI9340_BLACK);
        old_x1 = fix2int16(ship->x) - (CAR_WIDTH / 2);
        old_y1 = fix2int16(ship->y) + (CAR_HEIGHT / 2);
        tft_drawRoundRect(old_x1, old_y1, CAR_WIDTH, CAR_HEIGHT, RADIUS, ILI9340_RED);
    }
}

static char ball_index = 0;
bullet_t bullets[MAX_BULLETS];

//reset the bullets
void clear_bullets() {
    int i;
    for (i = 0; i < MAX_BULLETS; i++) {
        bullets[i].active = 0;
    }
}

// activate a bullet
void shoot_gun(ship_t* ship) {
    fix16 x = ship->x;
    fix16 y = ship->y;
    // Find tip of ship
    fix16 x1 = x + float2fix16(6 * sin(rotation));
    fix16 y1 = y + float2fix16(-6 * cos(rotation));
    bullet_t *bullet = &bullets[ball_index];
    bullet->x = x1;
    bullet->y = y1;
    bullet->vx = float2fix16(20 * sin(ship->rotation));
    bullet->vy = float2fix16(-20 * cos(ship->rotation));
    bullet->active = 1;
    ball_index = (ball_index + 1) % MAX_BULLETS;
}

// draw bullets and detect collisions
void draw_bullets() {
    int i;
    int j;
    for (i = 0; i < MAX_BULLETS; i++) {
        bullet_t *bullet = &bullets[i];
        if (bullet->active != 1)
            continue;
        tft_drawCircle(fix2int16(bullet->x), fix2int16(bullet->y), RADIUS, ILI9340_BLACK);
        for (j = 0; j < MAX_BULLETS; j++) {
            asteroid_t *asteroid = &asteroids[j];
            if (asteroid->active != 1) {
                continue;
            }
            fix16 dx = absfix16(bullet->x - asteroid->x);
            fix16 dy = absfix16(bullet->y - asteroid->y);
            // possible collision
            if (fix2int16(dx) <= (ASTEROID_RADIUS + RADIUS) && fix2int16(dy) <= (ASTEROID_RADIUS + RADIUS)) {
                fix16 sq_mag_rij = multfix16(dx, dx) + multfix16(dy, dy);
                // can't divide by zero  
                if (sq_mag_rij == 0) {
                    continue;
                }
                //confirmed collision
                if (fix2int16(sq_mag_rij) <= 4 * (ASTEROID_RADIUS + RADIUS)* (ASTEROID_RADIUS + RADIUS)) {
                    tft_drawCircle(fix2int16(asteroid->x), fix2int16(asteroid->y), ASTEROID_RADIUS, ILI9340_BLACK);
                    asteroid->active = 0;
                    init_asteroid(j);
                    bullet->active = 0;
                    ship.score++;
                    DmaChnEnable(dmaChn0);
                    break;
                }
            }
        }
        if (bullet->active != 1)
            continue;
        bullet->x += bullet->vx;
        bullet->y += bullet->vy;
        if (bullet->x > int2fix16(320) || bullet->x < int2fix16(0) || bullet->y < int2fix16(0) || bullet->y > int2fix16(240)) {
            bullet->active = 0;
            continue;
        }
        tft_drawCircle(fix2int16(bullet->x), fix2int16(bullet->y), RADIUS, ILI9340_WHITE);
    }
}

// High ADC value means left, low means right
// Returns an integer referring to the delta x should take
int horz_to_x(int joy_horz) {
    return joy_horz >> 2;
}

int vert_to_y(int joy_vert) {
    return joy_vert >> 2;
}

static int vert = 0, horz = 0;
// thread for evaluating every frame
static int x = 120, y = 160;

/* move asteroids and check them for colisions, also trigger rumble*/
static PT_THREAD(protothread_compute_asteroids(struct pt *pt)) {
    PT_BEGIN(pt);
    static int begin_time;
    init_asteroids();
    while (1) {
        if (ship.lives <= 0) {
            mPORTBClearBits(BIT_7);
            rumble = 0;
            break;
        } else {
            begin_time = PT_GET_TIME();
            draw_asteroids();
            //activate rumble
            if (rumble) {
                mPORTBSetBits(BIT_7);
            } else {
                mPORTBClearBits(BIT_7);
            }
            draw_bullets();
            inv_fps = SPF - (PT_GET_TIME() - begin_time);
            PT_YIELD_TIME_msec(inv_fps);
        }
    } // end while

    PT_END(pt);
} // end thread

/*read inputs and move ship, trigger game over*/
static PT_THREAD(protothread_ship(struct pt *pt)) {
    PT_BEGIN(pt);
    ship.x = int2fix16(160), ship.y = int2fix16(120), ship.rotation = 0, ship.lives = 5, ship.score = 0;
    clear_bullets();

    while (1) {
        if (ship.lives <= 0) {
            tft_fillScreen(ILI9340_BLACK);
            tft_setCursor(50, 50);
            tft_setTextColor(ILI9340_WHITE);
            tft_setTextSize(4);
            sprintf(buffer, "GAME OVER\n  Score = %d", ship.score);
            tft_writeString(buffer);
            game_over = 1;
            clear_bullets();
            init_asteroids();
            break;

        } else {

            draw_ship(&ship);
            horz = ReadADC10(0);
            vert = ReadADC10(1);
            int delta_x = interpret_adc(horz - calib_horz);
            int delta_y = interpret_adc(vert - calib_vert);
            if (ship.rotation == 0 && delta_x < 0)
                ship.rotation = SIN_TABLE_SIZE;
            ship.rotation = (ship.rotation + (delta_x / 2)) % SIN_TABLE_SIZE;
            if (delta_y < 0) {
                ship.x = ship.x + float2fix16(-(delta_y << 1) * sin(ship.rotation));
                ship.y = ship.y + float2fix16((delta_y << 1) * cos(ship.rotation));
            }
            read_A(game);
            if (a_press) {
                shoot_gun(&ship);
            }
            if (ship.x > int2fix16(320))
                ship.x = int2fix16(0);
            else if (ship.x < int2fix16(0))
                ship.x = int2fix16(320);
            else if (ship.y < int2fix16(0))
                ship.y = int2fix16(240);
            else if (ship.y > int2fix16(240))
                ship.y = int2fix16(0);
            PT_YIELD_TIME_msec(inv_fps * 2);
        }

    } // end while

    PT_END(pt);
} // end thread

// starting indexes for centerline lines
volatile int centerline[6] = {0, 48, 96, 144, 192, 240};

/*animate the centerline of the track*/
static PT_THREAD(protothread_track(struct pt *pt)) {
    PT_BEGIN(pt);
    tft_fillScreen(ILI9340_BLACK);
    tft_drawLine(5, 0, 5, 240, ILI9340_GREEN);
    tft_drawLine(315, 0, 315, 240, ILI9340_GREEN);
    char i;
    while (1) {
        if (ship.lives <= 0)
            break;
        tft_drawLine(160, 0, 160, 240, ILI9340_BLACK);
        for (i = 0; i < 6; i++) {
            centerline[i] = (centerline[i] + fix2int16(ship.speed)) % 288;
            tft_drawLine(160, centerline[i] - 30, 160, centerline[i], ILI9340_YELLOW);
        }
        PT_YIELD_TIME_msec(15);
    }
    PT_END(pt);
}

// counter for how long to wait before next spawn
volatile char counter = 20;
// index into which hazard to spawn next in hazard array
volatile char curr_hazard = 0;
//control variable for how fast to spawn hazards, set based on time
volatile char rate_control = 0;
volatile unsigned int sys_time_ms = 0;
volatile unsigned int sys_time_min = 0;
volatile unsigned int sys_time_seconds = 0;

/*read inputs, animate car, check for collisions, check for game over, */
static PT_THREAD(protothread_car(struct pt *pt)) {
    PT_BEGIN(pt);
    ship.x = int2fix16(160), ship.y = int2fix16(215), ship.rotation = 0, ship.lives = 4, ship.speed = int2fix16(MIN_SPEED), ship.score = 0;
    init_hazards();
    static int begin_time;
    while (1) {
        // check game over
        if (ship.lives <= 0) {
            tft_fillScreen(ILI9340_BLACK);
            tft_setTextColor(ILI9340_WHITE);
            tft_setTextSize(3);
            tft_setCursor(50, 50);
            sprintf(buffer, "GAME OVER\n  Score = %d", ship.score);
            tft_writeString(buffer);
            mPORTBClearBits(BIT_7);
            rumble = 0;
            rate_control = 0;
            game_over = 1;
            break;
        } else {
            begin_time = PT_GET_TIME(); //for calculating frame rate
            draw_ship(&ship);
            if (counter != 0) {
                counter--;
            // counter is 0, spawn a hazard, reset the count
            } else {
                spawn_hazard(curr_hazard);
                curr_hazard = (curr_hazard + 1) % MAX_HAZARDS;
                counter = (80 - (fix2int16(ship.speed) << 1)) >> rate_control;
            }
            //set rate control based on time elapsed
            if (rate_control < 3)
                rate_control = sys_time_seconds >> 1;
            move_hazards();
            draw_asteroids();
            horz = ReadADC10(0); // read the result of channel 9 conversion from the idle buffer
            vert = ReadADC10(1);
            read_A(game);
            read_B(game);
            if (a_press) {
                //play accel sound
                DmaChnEnable(dmaChn0);
                if (ship.speed < int2fix16(MAX_SPEED)) {
                    ship.speed = ship.speed + float2fix16(.2);
                    if (ship.speed > int2fix16(MAX_SPEED)) {
                        ship.speed = int2fix16(MAX_SPEED);
                    }
                }
            } else if (b_press) {
                //play screech sound
                DmaChnEnable(dmaChn1);
                if (ship.speed > int2fix16(MIN_SPEED)) {
                    ship.speed = ship.speed - float2fix16(.2);
                }
                if (ship.speed < int2fix16(MIN_SPEED)) {
                    ship.speed = int2fix16(MIN_SPEED);
                }
            } else {
                if (ship.speed > int2fix16(MIN_SPEED)) {
                    ship.speed = ship.speed - float2fix16(.05);
                }
            }
            int delta_x = interpret_adc(horz - calib_horz) << 1;
            int delta_y = interpret_adc(vert - calib_vert) << 1;
            fix16 new_x = ship.x + int2fix16(delta_x);
            fix16 new_y = ship.y + int2fix16(delta_y);
            if (new_x < int2fix16(305) && new_x > int2fix16(15)) {
                ship.x = new_x;
            }
            if (new_y < int2fix16(225) && new_y > int2fix16(15)) {
                ship.y = new_y;
            }
            //trigger rumble
            if (rumble) {
                mPORTBSetBits(BIT_7);
            } else {
                mPORTBClearBits(BIT_7);
            }
            inv_fps = ((SPF >> 1) - (PT_GET_TIME() - begin_time));
            PT_YIELD_TIME_msec(inv_fps);
        }
    } // end while

    PT_END(pt);
} // end thread

//=== Timer Thread =================================================
// print game stats, keep track of time and score for racing
static int press_count = 0;

static PT_THREAD(protothread_timer(struct pt *pt)) {
    PT_BEGIN(pt);
    while (1) {
        if (ship.lives <= 0) {
            sys_time_min = 0;
            sys_time_ms = 0;
            sys_time_seconds = 0;
            break;
        } else {
            PT_YIELD_TIME_msec(200);
            if (game == RACING) {
                // calculate time
                if (sys_time_ms == 80 && sys_time_seconds == 59)
                    sys_time_min++;
                if (sys_time_ms == 80) {
                    sys_time_seconds = (sys_time_seconds + 1) % 60;
                    if (game == RACING) {
                        ship.score = ship.score + fix2int16(ship.speed);
                    }
                }
                sys_time_ms = (sys_time_ms + 20) % 100;
            }
            // game over condition, set flag, play sound for end game
            tft_fillRoundRect(0, 10, 80, 40, 1, ILI9340_BLACK); // x,y,w,h,radius,color
            tft_setCursor(0, 10);
            tft_setTextColor(ILI9340_YELLOW);
            tft_setTextSize(1);
            // calculate FPS
            if (inv_fps == 0) {
                fps = FPS;
            } else if (inv_fps > 0) {
                fps = game ? FPS * 2 : FPS;
                // if we exceed the set frame rate
            } else {
                fps = 1000 / (SPF - inv_fps);
            }
            if (game == ASTEROIDS) {
                sprintf(buffer, "Score: %d\nLives: %d\nFPS: %d", ship.score, ship.lives, fps);
            } else {
                sprintf(buffer, "Score: %d\nLives: %d\nTime: %.2d:%.2d.%.2d\nFPS: %d", ship.score, ship.lives, sys_time_min, sys_time_seconds, sys_time_ms, fps);

                tft_writeString(buffer);
            }
        }
    } // END WHILE(1)
    PT_END(pt);
} // timer thread

int chan = 0;

static PT_THREAD(protothread_sd(struct pt *pt)) {
    PT_BEGIN(pt);
    SearchRec rec;
    UINT8 attributes = ATTR_MASK; // file can have any attributes
    while (1) {
        int y = 50;
        tft_setCursor(0, 0);
        tft_setTextSize(1);
        tft_setTextColor(ILI9340_WHITE);
        tft_fillScreen(ILI9340_BLACK);
        read_A(game);
        read_B(game);
        sprintf(buffer, "a: %d, b: %d\n", a_press, b_press);
        tft_writeString(buffer);
        tft_writeString("Showing all WAV\nfiles in root\ndirectory:"); //
        tft_setCursor(0, 50);
        INTDisableInterrupts();
        SD_Config();
        if (FindFirst("*.*", attributes, &rec) == 0) {// find bmp file print name to screen
            sprintf(buffer, "%s\t%u KB\n\r", rec.filename, rec.filesize / 1024);
            tft_writeString(buffer);
            SD_Config(); //resets SPI config and status bits

            while (FindNext(&rec) == 0) {//print all bmp file names 
                y += 10;
                tft_setCursor(0, y);
                sprintf(buffer, "%s\t%u KB\n\r", rec.filename, rec.filesize / 1024);
                tft_writeString(buffer);
                SD_Config(); //resets SPI config and status bits
            }
        } else {
            tft_writeString("No WAV files found");
        }
        INTEnableSystemMultiVectoredInt();
        DmaChnEnable(chan);
        chan = (chan + 1) % 2;
        PT_YIELD_TIME_msec(2000);
    }
    PT_END(pt);
}
int sel = 0;

// cursor for which game is to be selected in launcher
void draw_cursor(int sel) {
    if (sel == 0) {
        tft_fillCircle(40, 100, 2, ILI9340_BLACK);
        tft_fillCircle(40, 60, 2, ILI9340_CYAN);
    } else {
        tft_fillCircle(40, 60, 2, ILI9340_BLACK);
        tft_fillCircle(40, 100, 2, ILI9340_CYAN);
    }
}

/*main thread, launches the selected game, on game over, return here*/
static PT_THREAD(protothread_launcher(struct pt *pt)) {
    PT_BEGIN(pt);
    tft_fillScreen(ILI9340_BLACK);
    draw_cursor(0);
    while (1) {
        tft_setCursor(50, 50);
        tft_setTextColor(ILI9340_WHITE);
        tft_setTextSize(4);
        sprintf(buffer, "Asteroids\n  PICRacer32\n");
        tft_writeString(buffer);
        vert = ReadADC10(1);
        //check which game the user is selecting with joystick
        if (interpret_adc(vert - calib_vert) == 3) {
            sel = 1;
        } else if (interpret_adc(vert - calib_vert) == -3) {
            sel = 0;
        }
        draw_cursor(sel);
        read_A(game);
        if (a_press) {
            //asteroids was selected
            if (sel == 0) {
                tft_fillScreen(ILI9340_BLACK);
                game = ASTEROIDS;
                SD_Config();
                setupDMA(0, "sound.wav");
                while (1) {
                    PT_SCHEDULE(protothread_ship(&pt_ship));
                    PT_SCHEDULE(protothread_compute_asteroids(&pt_compute_asteroids));
                    PT_SCHEDULE(protothread_timer(&pt_timer));
                    // game over, wait before reseting
                    if (game_over) {
                        PT_YIELD_TIME_msec(500);
                        while (!a_press) {
                            read_A(game);
                        }
                        PT_YIELD_TIME_msec(300);
                        game_over = 0;
                        tft_fillScreen(ILI9340_BLACK);
                        break;
                    }
                }
            } else {
                // racing was selected
                tft_fillScreen(ILI9340_BLACK);
                game = RACING;
                SD_Config();
                setupDMA(0, "accel.wav");
                setupDMA(1, "screech.wav");
                while (1) {
                    PT_SCHEDULE(protothread_track(&pt_track));
                    PT_SCHEDULE(protothread_car(&pt_car));
                    PT_SCHEDULE(protothread_timer(&pt_timer));
                    if (game_over) {
                        PT_YIELD_TIME_msec(500);
                        while (!a_press) {
                            read_A(game);
                        }
                        PT_YIELD_TIME_msec(300);
                        game_over = 0;
                        tft_fillScreen(ILI9340_BLACK);
                        break;
                    }
                }
            }
        }
        PT_YIELD_TIME_msec(5);
    } // END WHILE(1)
    PT_END(pt);
} // timer 


// === Main  ======================================================

void main(void) {
    SearchRec rec;
    UINT8 attributes = ATTR_MASK; // file can have any attributes

    //    // === config threads ==========
    //    // turns OFF UART support and debugger pin, unless defines are set
    PT_setup();
    //    INTEnableSystemMultiVectoredInt();


    ///////////////////////////////////////////////////////
    setupDAC();

    PT_INIT(&pt_adc);
    PT_INIT(&pt_compute_asteroids);
    PT_INIT(&pt_ship);
    PT_INIT(&pt_launcher);
    PT_INIT(&pt_sd);
    PT_INIT(&pt_timer);

    tft_init_hw();
    tft_begin();
    tft_fillScreen(ILI9340_BLACK);
    //240x320 vertical display
    tft_setRotation(3); // Use tft_setRotation(1) for 320x240



    if (!FSInit()) {
        tft_fillScreen(ILI9340_RED); //print this if init fails
        while (1);
    }

    spicon_fs = SPI2CON;
    spicon2_fs = SPI2CON2; // reset configuration bits so that TFT writes can occur

    tft_setCursor(0, 0);
    tft_setTextSize(1);
    tft_setTextColor(ILI9340_WHITE);
    //    tft_writeString("Showing all WAV\nfiles in root\ndirectory:"); //
    tft_setCursor(0, 50);
    SPI2STAT = 0;
    //    mSPI1ClearAllIntFlags();
    SD_Config(); //resets SPI config and status bits

    // the ADC ///////////////////////////////////////
    // configure and enable the ADC
    CloseADC10(); // ensure the ADC is off before setting the configuration

    // define setup parameters for OpenADC10
    // Turn module on | ouput in integer | trigger mode auto | enable autosample
    // ADC_CLK_AUTO -- Internal counter ends sampling and starts conversion (Auto convert)
    // ADC_AUTO_SAMPLING_ON -- Sampling begins immediately after last conversion completes; SAMP bit is automatically set
    // ADC_AUTO_SAMPLING_OFF -- Sampling begins with AcquireADC10();
#define PARAM1  ADC_FORMAT_INTG16 | ADC_CLK_AUTO | ADC_AUTO_SAMPLING_ON                                 //

    // define setup parameters for OpenADC10
    // ADC ref external  | disable offset test | disable scan mode | do 1 sample | use single buf | alternate mode off
#define PARAM2  ADC_VREF_AVDD_AVSS | ADC_OFFSET_CAL_DISABLE | ADC_SCAN_ON | ADC_SAMPLES_PER_INT_2 | ADC_ALT_BUF_OFF | ADC_ALT_INPUT_OFF
    //
    // Define setup parameters for OpenADC10
    // use peripherial bus clock | set sample time | set ADC clock divider
    // ADC_CONV_CLK_Tcy2 means divide CLK_PB by 2 (max speed)
    // ADC_SAMPLE_TIME_5 seems to work with a source resistance < 1kohm
#define PARAM3 ADC_CONV_CLK_PB | ADC_SAMPLE_TIME_5 | ADC_CONV_CLK_Tcy2 //ADC_SAMPLE_TIME_15| ADC_CONV_CLK_Tcy2

    // define setup parameters for OpenADC10
    // set AN11 and  as analog inputs
#define PARAM4	ENABLE_AN11_ANA | ENABLE_AN5_ANA // pin 24, pin 7

    // define setup parameters for OpenADC10
    // do not assign channels to scan
#define PARAM5	SKIP_SCAN_AN0 | SKIP_SCAN_AN1 | SKIP_SCAN_AN2 | SKIP_SCAN_AN3 | SKIP_SCAN_AN4 | SKIP_SCAN_AN6 | SKIP_SCAN_AN7 | SKIP_SCAN_AN8 | SKIP_SCAN_AN9 | SKIP_SCAN_AN10 | SKIP_SCAN_AN12 | SKIP_SCAN_AN13 | SKIP_SCAN_AN14 | SKIP_SCAN_AN15


    // use ground as neg ref for A | use AN11 for input A     
    // configure to sample AN11 
    SetChanADC10(ADC_CH0_NEG_SAMPLEA_NVREF); // configure to sample AN4 
    OpenADC10(PARAM1, PARAM2, PARAM3, PARAM4, PARAM5); // configure ADC using the parameters defined above

    EnableADC10(); // Enable the ADC
    INTEnableSystemMultiVectoredInt();
    srand(SEED);
    calibrate_joystick();
    EnablePullDownB(BIT_10 | BIT_8);
    EnablePullDownA(BIT_3);
    mPORTBSetPinsDigitalIn(BIT_10 | BIT_8);
    mPORTASetPinsDigitalIn(BIT_3);
    mPORTBSetPinsDigitalOut(BIT_7);
    mPORTBClearBits(BIT_7);
    //    while(1);
    while (1) {
        PT_SCHEDULE(protothread_launcher(&pt_launcher));
    }

} // main

// === end  ======================================================

