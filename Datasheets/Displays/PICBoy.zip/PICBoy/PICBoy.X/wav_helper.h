#include "MDD_includes/FSIO.h"

#define allGood             0
#define incorrectHeaderSize 1
#define riff                2
#define wav                 3
#define fmt                 4
#define notPCM              5

#define SOUND_SIZE 11500
// Sounds
volatile UINT8 SOUND0[SOUND_SIZE];
volatile UINT8 SOUND1[SOUND_SIZE];

UINT8 getWavHeader(FSFILE * pointer);
void getParameters(UINT8 * bitsPerSample, UINT8 * numberOfChannels,
                        UINT32 * dataSize, UINT32 * sampleRate,
                        UINT32 * blockAlign);