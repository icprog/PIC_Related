YOU MUST AGREE THIS TERMS AND CONDITIONS. THIS SOFTWARE IS
PROVIDED BY NORITAKE CO., INC "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR SORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------
ABOUT THIS DEMO
This project demonstrates how to use the Noritake_VFD_CUU_Graph
code library to display horizontal bar graphs on Noritake
CU-U Vacuum Fluorescent Display (VFD) modules. You MUST download
and install the Noritake_VFD_CUU code library before running
the demo.

	http://www.noritake-elec.com

Please refer to the instructions on the download page and
"README" included with the Noritake_VFD_CUU code library for
information on how to install the Noritake_VFD_CUU, 
Noritake_VFD_CUU_Graph code libraries, and demos. This document
assumes that you have already configured "config.h" file in the
Noritake_VFD_CUU code library as described in those documents.

For more information on the methods used in this document, please
refer to the method reference documentation in the
Noritake_VFD_CUU and Noritake_VFD_CUU_Graph code libraries.

----------------------------------------------------------------
BEHAVIOR
Three graphs will appear on the screen.

Graph 1 is in the top left corner. Graph 1 is 5 columns wide and
1 line tall. It displays only a caption, "-RND-".

Graph 2 is in the top right. Graph 2 is 6 columns wide and 1
line tall. The data source for this graph is a random number
generator. The value of the data source will be displayed
on the right as a percentage.

Graph 3 is below graph 2. Graph 3 is 10 columns wide and 1 line
tall. The data source for this graph is a uniformly increasing
value. This value will increase until it reaches the maximum
value then return to the minimum. The value of the data source
will be displayed to the left of this graph.

----------------------------------------------------------------
KEY POINTS
1) Create an instance of Noritake_VFD_CUU.
2) Create instances of Noritake_VFD_CUU_Graph for graphs 1,
   2, and 3.
3) Initialize the VFD module with the vfd.CUU_init() method.
4) Set the graph style with the setStyle() method. This will
   define the user-defined fonts needed to display the graph.
   
   All 8 user-define font characters are used to display
   graphs with the Noritake_VFD_CUU_Graph code library.

   Graph styles include:
	Noritake_VFD_CUU_Graph::Hollow
	Noritake_VFD_CUU_Graph::Center
	Noritake_VFD_CUU_Graph::Full

   Please refer to "void setStyle(Noritake_VFD_CUU_Graph::Style style)"
   the methods reference documentation for more information.
5) Set the size and position of the graphs with the setSize()
   and setPosition() methods.
6) Set the caption and fill character with the setCaption() and
   setFillCharacter() methods.
7) Set the ranges of values that the graph will handle with the
   setRange() methods.
8) Change the data source value with the setValue() method for
   each bar.
9) Print the data source values for the graphs.
10)Display the graph with the display() method.

----------------------------------------------------------------
LISTING
#include "../Noritake_VFD_CUU/src/config.h"
#include "../Noritake_VFD_CUU_Graph/src/Noritake_VFD_CUU_Graph.h"
#include "../Noritake_VFD_CUU/src/Noritake_VFD_CUU.h"
#include <stdlib.h>
#include <util/delay.h>

Noritake_VFD_CUU vfd;
Noritake_VFD_CUU_Graph graph1(vfd);
Noritake_VFD_CUU_Graph graph2(vfd);
Noritake_VFD_CUU_Graph graph3(vfd);

int main() {
	int min=0;
	int max=256;

	vfd.CUU_init();

	// Select the style
	// Graph styles include:
	//     Noritake_VFD_CUU_Graph::Hollow
	//     Noritake_VFD_CUU_Graph::Center
	//     Noritake_VFD_CUU_Graph::Full
	graph1.setStyle(Noritake_VFD_CUU_Graph::Hollow);

	// Set the sizes of the graphs
	graph1.setSize(5,1);
	graph2.setSize(6,1);
	graph3.setSize(10,1);

	// Position the graphs
	graph2.setPosition(5,0);
	graph3.setPosition(5,1);

	graph1.setFillCharacter('-');	// Set the fill character to "-"
	graph1.setCaption(0, "RND");	// Set the caption
	
	// Set the value ranges
	graph2.setRange(0,min,max);
	graph3.setRange(0,min,max);
	
	for (int i=0; ; i++) {
		// Set values for graph
		graph2.setValue(0, rand() % (max-min)+min);
		graph3.setValue(0, i % (max-min)+min);
		
		// Show graph 3 value
		vfd.CUU_setCursor(0,1);
		vfd.print("     ");
		vfd.CUU_setCursor(0,1);
		vfd.print("i:");
		vfd.print(graph3.getValue(0));

		// Show graph 2 percent
		vfd.CUU_setCursor(13,0);
		vfd.print("     ");
		vfd.CUU_setCursor(13,0);
		vfd.print(graph2.getPercentValue(0));
		vfd.print("%");

		// Display graphs
		graph1.display();
		graph2.display();
		graph3.display();
		
		_delay_ms(100);
	}
}

----------------------------------------------------------------
E-M-0105-01 06/25/2012
----------------------------------------------------------------
CHANGES
Revision 1
    Code listing changed to follow new directory structure.
SUPPORT

For further support, please contact:
	Noritake Co., Inc.
	2635 Clearbrook Dr 
	Arlington Heights, IL 60005 
	800-779-5846 
	847-439-9020
	support.ele@noritake.com

All rights reserved. © Noritake Co., Inc.