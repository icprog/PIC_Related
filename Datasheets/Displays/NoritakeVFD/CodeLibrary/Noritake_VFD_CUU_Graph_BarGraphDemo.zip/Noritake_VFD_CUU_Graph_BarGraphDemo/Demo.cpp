#include "../src/config.h"
#include "../Noritake_VFD_CUU_Graph/src/Noritake_VFD_CUU_Graph.h"
#include "../src/Noritake_VFD_CUU.h"
#include <stdlib.h>
#include <util/delay.h>

Noritake_VFD_CUU vfd;
Noritake_VFD_CUU_Graph graph1(vfd);
Noritake_VFD_CUU_Graph graph2(vfd);
Noritake_VFD_CUU_Graph graph3(vfd);

int main() {
	int min=0;
	int max=256;

	vfd.CUU_init();

	// Select the style
	// Graph styles include:
	//     Noritake_VFD_CUU_Graph::Hollow
	//     Noritake_VFD_CUU_Graph::Center
	//     Noritake_VFD_CUU_Graph::Full
	graph1.setStyle(Noritake_VFD_CUU_Graph::Hollow);

	// Set the sizes of the graphs
	graph1.setSize(5,1);
	graph2.setSize(6,1);
	graph3.setSize(10,1);

	// Position the graphs
	graph2.setPosition(5,0);
	graph3.setPosition(5,1);

	graph1.setFillCharacter('-');	// Set the fill character to "-"
	graph1.setCaption(0, "RND");	// Set the caption
	
	// Set the value ranges
	graph2.setRange(0,min,max);
	graph3.setRange(0,min,max);
	
	for (int i=0; ; i++) {
		// Set values for graph
		graph2.setValue(0, rand() % (max-min)+min);
		graph3.setValue(0, i % (max-min)+min);
		
		// Show graph 3 value
		vfd.CUU_setCursor(0,1);
		vfd.print("     ");
		vfd.CUU_setCursor(0,1);
		vfd.print("i:");
		vfd.print(graph3.getValue(0));

		// Show graph 2 percent
		vfd.CUU_setCursor(13,0);
		vfd.print("     ");
		vfd.CUU_setCursor(13,0);
		vfd.print(graph2.getPercentValue(0));
		vfd.print("%");

		// Display graphs
		graph1.display();
		graph2.display();
		graph3.display();
		
		_delay_ms(100);
	}
}
