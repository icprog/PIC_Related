/*********** LCD  Part Start  **********/
void lcd_init(void)
{
DelayMs(15);
lcd_tris = lcd_tris && 0xF0; // Lower Nibble Interface
RS_tris = EN_tris = 0;
RS = EN = 0;
lcd_cmd_4bit(0x03);
DelayMs(5);
lcd_cmd_4bit(0x03);
DelayMs(5);
lcd_cmd_4bit(0x03);
DelayMs(5);
lcd_cmd_4bit(0x02);
lcd_cmd_byte(0x28);
lcd_cmd_byte(0x08);
lcd_cmd_byte(0x01);
lcd_cmd_byte(0x06);
lcd_cmd_byte(0x0c);
}
/**********/
void lcd_cmd_4bit(char a)
{lcd_port =lcd_port&(0xf0);
 lcd_port = lcd_port|a;
 RS =0;
 EN = 1;
 #asm
 nop
 nop
 nop
#endasm
 EN = 0;
}
/***************/
void lcd_cmd_byte(char a)
{ char z = a;
 CARRY = 0;
 lcd_command((a>>4)&0x0f);
  a = z;
 lcd_command(a&0x0f);
}
/***************/
void lcd_command(char ch)
{   DelayMs(5);
	lcd_port &= 0xF0;
    RS = 0; 
    EN = 0;
    lcd_port |= ch;
    EN = 1; 
#asm
    nop
    nop
	nop
#endasm
    EN=0;
}
/*************/
void lcd_data_byte(char a)
{char z = a; CARRY = 0;
 lcd_data((a>>4)&0x0f);
  a = z;
 lcd_data(a&0x0f); 
}
/******************/
void lcd_data(char ch)
{   DelayMs(5);
	RS = 1; 
    EN =0;
	lcd_port &= 0xF0;
    lcd_port |= ch;
    EN = 1; 
#asm
    nop
    nop
	nop
#endasm
    EN = 0;
}
/*********/
void lcd_1Home(void)
{
 lcd_cmd_byte(0x80);
}
/*******/
void lcd_clear(void)
{
lcd_cmd_byte(0x01);
}
/*********/
void lcd_2Home(void)
{
 lcd_cmd_byte(0xc0);
}
/////////////////////////
void lcd_goto1(char a)
{
 lcd_cmd_byte(0x80+ a);
}
void lcd_goto2(char a)
{
 lcd_cmd_byte(0xC0+ a);
}
void lcd_space()
{ lcd_data_byte(' ');}
/*********  End of LCD Part ***********/
