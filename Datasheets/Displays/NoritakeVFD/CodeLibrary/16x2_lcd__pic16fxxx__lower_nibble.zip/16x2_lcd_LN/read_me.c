/********************************
  This is an example for the LCD interface functions. This will display :
   STI  Soft Fuel   -- in First Line
   INSIDE   -- in Second  Line
*/
#include"htc.h"
#include "delay.h"
#include "delay.c"
#include "lcd.h"
//***********************************
#define    lcd_port	    PORTB 
#define	   lcd_tris 	TRISB
static   bit   RS	@ ((unsigned)&PORTB*8+4);	// rs
static   bit   EN	@ ((unsigned)&PORTB*8+5);	// En
static   bit  RS_tris @ ((unsigned)&TRISB*8+4);    // rs
static   bit  EN_tris @ ((unsigned)&TRISB*8+5);    // En
//***********************************************
const char sti_msg1[] = {"STI  soft  fuel"};
const char	sti_msg2[] = {"inside"};
//**************************************
void disp_sti_msg(void)
{char i,j;
 lcd_clear();
 for (i=0;i<15;i++)
		{j = sti_msg1[i];
         lcd_data_byte(j);
        }
lcd_2Home();
for (i=0;i<10;i++)
		{j = sti_msg2[i];
         lcd_data_byte(j);
        }
 }
 //
//
Void init_ports(void)
{lcd_tris = lcd_port = 0;
RS_tris  =  EN_tris = EN =RS = 0;
}
Void main(void)
{
init_ports();
lcd_init();
disp_sti_msg ();
while(1);
}
/********************************/
#include "lcd.c"
/*******************************/