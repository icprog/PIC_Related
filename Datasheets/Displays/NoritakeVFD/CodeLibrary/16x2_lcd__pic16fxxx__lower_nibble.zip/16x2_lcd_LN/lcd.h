#define lcd_h

/**  Function Declaration  Start  **********/
void lcd_clear(void);
void lcd_data_byte(char);
void lcd_2Home(void);
void lcd_goto2(char);
void lcd_goto1(char);
void lcd_blank(void);
void lcd_cmd_4bit(char);
void lcd_cmd_byte(char);
void lcd_command(char);
void lcd_data(char);
void lcd_init(void);
/**  Function Declaration  End  **********/