﻿****************************************************************
		NORITAKE VFD CU-U GRAPH LIBRARY
****************************************************************

YOU MUST AGREE THIS TERMS AND CONDITIONS. THIS SOFTWARE IS
PROVIDED BY NORITAKE CO., INC "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR SORT (INCLUDING NEGLIGENCE OR
OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

----------------------------------------------------------------
ABOUT THIS LIBRARY
The Noritake_VFD_CUU_Graph code library takes input from a data
source and displays horizontal bar graphs to Noritake CU-U
Vacuum Fluorescent Display (VFD) modules. The
Noritake_VFD_CUU_Graph code library requires the Noritake_VFD_CUU
code library. Please download the latest version before use.

	http://www.noritake-elec.com

Please refer to the instructions on the download page and
"README" included with the Noritake_VFD_CUU code library for
information on how to install the Noritake_VFD_CUU and
Noritake_VFD_CUU_Graph code libraries. This document assumes
that you have already configured "config.h" file in the
Noritake_VFD_CUU code library as described in those documents.

For more information on the methods used in this document, please
refer to the method reference documentation in the
Noritake_VFD_CUU and Noritake_VFD_CUU_Graph code libraries.

----------------------------------------------------------------
GETTING STARTED
1) Include the following into your project:
	"../Noritake_VFD_CUU/src/config.h"
	"../Noritake_VFD_CUU/src/Noritake_VFD_CUU.h"
	"../Noritake_VFD_CUU_Graph/src/Noritake_VFD_CUU_Graph.h"
2) Create an instance of Noritake_VFD_CUU_Graph
3) Select which graph style you want to use. Setting the
  graph style will create the user-defined fonts that are used
  to display the graph. All user-defined font characters are
  used.

	Example:
	graph.setStyle(Noritake_VFD_CUU_Graph::Bar);
	or
	graph.setStyle(Noritake_VFD_CUU_Graph::Center);
	or
	graph.setStyle(Noritake_VFD_CUU_Graph::Hollow);

4) Set the position of the graph with setPosition(x,y)

	Example:
	If you want the top left-hand corner to be at column 5
	and line 0, use:
	graph.setPosition(5, 0);

5) Set the size of the graph with setSize(width,height).

	Example:
	If you want the graph to be 10 columns wide and 2
	lines tall, use:
	graph.setSize(10, 2);

6) Set the minimum and maximum values that a data source
  value may take with setRange(src, min, max).

	Example:
	If the range of the first data source were between
	-10 and 10 (inclusive), use:
	graph.setRange(0, -10, 10);

7) Change the value of the data source with setValue(src, value).

	Example:
	To set the first bar to be half full, use:
	graph.setValue(0, 5);

8) Repeat steps 6 and 7 for the second data source since the
  graph was specified to have two data sources by setSize().

	Example:
	graph.setRange(1, -20, 20);
	graph.setValue(1, 0);

9) Use display() to display the graph.

When you have completed these steps, your source should look like:

	#include "../Noritake_VFD_CUU/src/config.h"
	#include "../Noritake_VFD_CUU/src/Noritake_VFD_CUU.h"
	#include "../Noritake_VFD_CUU_Graph/src/Noritake_VFD_CUU_Graph.h"
	Noritake_VFD_CUU vfd;
	Noritake_VFD_CUU_Graph graph(vfd);
	int
	main() {
		vfd.CUU_init();
		graph.setStyle(Noritake_VFD_CUU_Graph::Hollow);
		graph.setPosition(5, 0);
		graph.setSize(10, 2);
		graph.setRange(0, 0, 10);
		graph.setValue(0, 5);
		graph.setRange(1, -20, 20);
		graph.setValue(1, 0);
		graph.display();
	}
	
----------------------------------------------------------------
E-M-0056-00 07/01/2011
----------------------------------------------------------------
SUPPORT

For further support, please contact:
	Noritake Co., Inc.
	2635 Clearbrook Dr 
	Arlington Heights, IL 60005 
	800-779-5846 
	847-439-9020
	support.ele@noritake.com

All rights reserved. © Noritake Co., Inc.
