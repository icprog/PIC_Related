class Noritake_VFD_CUU;

class Noritake_VFD_CUU_Graph {
	public:

	enum Style {
		Full,
		Center,
		Hollow
	};

	private:
	static Style style;					// graph style
	int val[NORITAKE_VFD_LINES];	// source values
	int min[NORITAKE_VFD_LINES];	// maximum value/scale
	int max[NORITAKE_VFD_LINES];	// maximum value/scale
	const char *caption[NORITAKE_VFD_LINES]; // caption
	unsigned char width;			// width of graph
	unsigned char height;			// height of graph
	unsigned char x;				// x position of the graph
	unsigned char y;				// y position
	char fillCharacter;				// character to fill captions with
	Noritake_VFD_CUU &vfd;			// VFD to draw use

	public:

	Noritake_VFD_CUU_Graph(Noritake_VFD_CUU &vfd): vfd(vfd) {
		x=0;
		y=0;
		fillCharacter = ' ';
		style = Hollow;
		width=NORITAKE_VFD_COLS/2;
		height=NORITAKE_VFD_LINES;
		for (int i=0; i<NORITAKE_VFD_LINES; i++) {
			min[i]=max[i]=val[i]=0;
			caption[i] = 0;
		}
	}
	void setStyle(Style style);
	void setFillCharacter(char c);
	void setPosition(int x, int y);
	void setSize(int width, int height);
	void setRange(int src, int min, int max);
	int getMin(int src);
	int getMax(int src);
	void setValue(int src, int val);
	int getValue(int src);
	int getPercentValue(int src);
	void setCaption(int src, const char *text);
	const char *getCaption(int src);
	void clearCaption(int src);
	void display();
};
