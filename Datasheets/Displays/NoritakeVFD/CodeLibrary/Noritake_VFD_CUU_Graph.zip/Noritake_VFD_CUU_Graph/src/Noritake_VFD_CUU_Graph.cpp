#include <string.h>
#include "../../src/config.h"
#include "../../src/Noritake_VFD_CUU.h"
#include "Noritake_VFD_CUU_Graph.h"

//Select the style of the graph. When setStyle() is called, user-
//defined characters are created to represent the bar graphs.
//You must not alter any custom characters while a graph is
//being displayed on the screen.
//All graphs on the screen will use the same graph style.
//style: style of graph to use
void
Noritake_VFD_CUU_Graph::setStyle(Noritake_VFD_CUU_Graph::Style style) {
	uint8_t udf[] = {
		0b00000,
		0b00000,
		0b00000,
		0b00000,
		0b00000,
		0b00000,
		0b00000,
		0b00000
	};
	static uint8_t hollow[][8] = {
		{	0b01100,
			0b01100,
			0b01100,
			0b01100,
			0b01100,
			0b01100,
			0b01100,
			0b00000 },
		{	0b01110,
			0b01010,
			0b01010,
			0b01010,
			0b01010,
			0b01010,
			0b01110,
			0b00000 },
		{
			0b01111,
			0b01001,
			0b01001,
			0b01001,
			0b01001,
			0b01001,
			0b01111,
			0b00000 },
		{	0b11000,
			0b01000,
			0b01000,
			0b01000,
			0b01000,
			0b01000,
			0b11000,
			0b00000},
		{	0b11100,
			0b00100,
			0b00100,
			0b00100,
			0b00100,
			0b00100,
			0b11100,
			0b00000},
		{	0b11111,
			0b00001,
			0b00001,
			0b00001,
			0b00001,
			0b00001,
			0b11111,
			0b00000},
		{	0b11111,
			0b00000,
			0b00000,
			0b00000,
			0b00000,
			0b00000,
			0b11111,
			0b00000},
		{	0b01111,
			0b01000,
			0b01000,
			0b01000,
			0b01000,
			0b01000,
			0b01111,
			0b00000 }};

	this->style = style;

	switch (this->style) {
	case Full:	
		for (int i=0; i<5; i++) {
			for (int j=0; j<7; j++)
				udf[j] |= 1<<(4-i);
			vfd.CUU_createChar(i, udf);
		}
		break;
	case Center:
		for (int i=0; i<3; i++) {
			for (int j=0; j<7; j++)
				udf[j] |= 1<<(3-i);
			vfd.CUU_createChar(i, udf);
		}
		break;
	case Hollow:
		for (int i=0; i<8; i++)
			vfd.CUU_createChar(i, hollow[i]);
		break;
	default:
			return; // abort
	}

	
}

Noritake_VFD_CUU_Graph::Style Noritake_VFD_CUU_Graph::style;

//Set the character that will be used to fill the space
//if the caption does not take up the entire width.
//c: character to use
void
Noritake_VFD_CUU_Graph::setFillCharacter(char c) {
	this->fillCharacter = c;
}



//Set the position of the top-left corner of the graph.
//x: x coordinate of the left side of the graph
//y: y coordinate of the top of the graph
void
Noritake_VFD_CUU_Graph::setPosition(int x, int y) {
	this->x = x;
	this->y = y;
}


//Set the size of the graph. The height is also the number of
//source items.
//width: width of the graph
//height: height of the graph (number of source items)
void
Noritake_VFD_CUU_Graph::setSize(int width, int height) {
	this->width = width;
	this->height = height;
}

//Set the minimum and maximum value of the given source item.
//src: the source item
//min: minimum value that data can have
//max: maximum value that data can have
void
Noritake_VFD_CUU_Graph::setRange(int src, int min, int max) {
	if (src < this->height && min <= max) {		
		this->min[src] = min;
		this->max[src] = max;		
	}
}

//Get the maximum value of the given source item.
//src: the source item
int
Noritake_VFD_CUU_Graph::getMax(int src) {
	if (src < this->height)
		return this->max[src];
	return 0;
}

//Get the maximum value of the given source item.
//src: the source item
int
Noritake_VFD_CUU_Graph::getMin(int src) {
	if (src < this->height)
		return this->min[src];
	return 0;
}

//Set the text to be displayed instead of the source item value
//on the given line. If text is NULL, then the source item is
//shown. This is equivalent to calling clearCaption(src);
//src: the source item line number
//text: the text to be displayed; Use NULL to display the source
//	value instead of a caption
void
Noritake_VFD_CUU_Graph::setCaption(int src, const char *text) {
	if (src < this->height)
		caption[src] = text;
}

//Get the caption on the given line. If there is no caption set
//on that line, then NULL is returned.
//src: line number
const char*
Noritake_VFD_CUU_Graph::getCaption(int src) {
	if (src < this->height)
		return caption[src];
	return 0;
}

//Remove the caption from the given line. If no caption was set,
//then this function has no effect. This is equivalent to
//setCaption(src, NULL);
//src: line number
void
Noritake_VFD_CUU_Graph::clearCaption(int src) {
	if (src < this->height)
		caption[src] = 0;
}


//Set the value of the source item. This function does not prevent
//you from setting values that are smaller than 0 or larger than the
//maximum even though they will not be displayed.
//src: the source item
//val: the value of the source item
void
Noritake_VFD_CUU_Graph::setValue(int src, int val) {
	if (src < this->height)
		this->val[src] = val;
}

//Get the value of the given source item. This value may be smaller
//than 0 or larger than maximum.
//src: the source item
int
Noritake_VFD_CUU_Graph::getValue(int src) {
	if (src < this->height)
		return this->val[src];
	return 0;
}

//Get the value of the given source item as a percentage.
//If the source data was not in the range [min,max] then this
//value may be below 0 or above 100.
//src: the source item
int
Noritake_VFD_CUU_Graph::getPercentValue(int src) {
	return (getValue(src) - getMin(src)) * 100 / (getMax(src) - getMin(src));
}



//Display the graph.
void
Noritake_VFD_CUU_Graph::display() {
	int i, j;
	char full, base = 0;
	int parts;

	switch (this->style) {
	case Full: full=0x04; parts = 5; break;
	case Center: full=0x02; parts = 3; break;
	case Hollow: full=0x06; parts = 4; break;
	default: full = parts = 2; break;
	}

	for (i=0; i<this->height; i++) {
		vfd.CUU_setCursor(this->x, this->y + i);
		if (this->caption[i]) {
			int len = strlen(caption[i]);
			int pad = (width - len)/2;
			int odd = (width - len)%2;

			for (int c=0; c<pad; c++)
				vfd.print(this->fillCharacter);
			vfd.print(caption[i]);
			for (int c=0; c<pad+odd; c++)
				vfd.print(this->fillCharacter);
			continue;
		}

		int w = getPercentValue(i) * width / 100;
		int part = getPercentValue(i) * width * parts / 100 % parts;

		if (w < 0) {	// VALUE OUT OF RANGE
			for (j=0; j<width; j++)
				vfd.print((char)' ');
			continue;
		}

		if (w > width)	// DO NOT WRITE OFF SCREEN
			w = width;

		switch (this->style) {
		case Hollow:
			if (w == 0) {
				switch (part) {
				case 0:	vfd.print((char)' '); break;
				case 1: vfd.print((char)0x00); break;
				case 2: vfd.print((char)0x01); break;
				case 3: vfd.print((char)0x02); break;
				}
				vfd.print(' ');
			} else {
				if (w)
					vfd.print((char)0x07);
				for (j=1; j<w - (w==width?1:0); j++)	// Display full blocks
					vfd.print((char)0x06);
				
				switch (part) {
				case 0:	vfd.print((char)((w==width)?0x05: 0x03)); break;
				case 1: vfd.print((char)0x03); break;
				case 2: vfd.print((char)0x04); break;
				case 3: vfd.print((char)0x05); break;
				default: vfd.print((char)0x00); break;
				}
			}
			break;

		case Full:
		case Center:
			for (j=0; j<w; j++)				// Display full blocks
				vfd.print(full);
			if (w < width) {				// DO NOT WRITE OFF SCREEN
				if (part)					// Display one partial block
					vfd.print((char)(base + part-1));
				else
					vfd.print((char)' ');
			}
			break;
		}
		for (j=w+1; j<width; j++) // Fill right with space
				vfd.print((char)' ');
	}
}
