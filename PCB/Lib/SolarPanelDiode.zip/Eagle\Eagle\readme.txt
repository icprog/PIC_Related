 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: C:\EMA\ExportFolder\0\192599\Output\Eagle\Eagle\Eagle.xml
 
 
To import your new library into Eagle:
1. Start Eagle.
2. In the control panel window, Select File -> New -> Library from the menu.
3. In the blank library window, select File -> Execute Script from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
7. Use File -> Save (or Save As..) to save the library to the desired location in Eagle native format.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q
 
 


Ultra Librarian Gold 8.2.165 Process Report


Message - Padstack "RX422Y408D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX36Y126D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX424Y420D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX40Y150D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX420Y396D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX38Y138D0T" Shape(4) is a CIRCLE with no diameter.

TextStyle count:  25
Padstack count:   6
Pattern count:    3
Symbol count:     1
Component count:  1

Export


